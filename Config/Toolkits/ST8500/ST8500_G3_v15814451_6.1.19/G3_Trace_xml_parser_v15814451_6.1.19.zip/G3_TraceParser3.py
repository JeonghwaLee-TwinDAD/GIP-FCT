import sys
import os
sys.path.append(os.path.dirname(os.path.realpath(__file__)))
import serial 
from xml.etree import ElementTree
import configparser
import time
import codecs
import argparse
import threading

CONFIGURATION_FILE = os.path.dirname(os.path.realpath(__file__))+"\config.ini"



class SerialPort(object):

    def __init__(self, com_port):

        try:    
            self.file = serial.Serial(port = com_port, \
                                      baudrate = 230400, \
                                      bytesize = serial.EIGHTBITS, \
                                      parity = serial.PARITY_NONE, \
                                      stopbits = serial.STOPBITS_ONE, \
                                      timeout = 1, \
                                      xonxoff = False, \
                                      rtscts = False, \
                                      dsrdtr = False) 
        except:
            print("*** ERR: cannot open port " + com_port)
            raise
        if (self.file.isOpen() == True):
            self.file.close()
        self.file.open()    
        self.file.setRTS(False)
        self.file.setDTR(False)        
        self.file.reset_input_buffer()
        
    def read_binary_trace(self, stop_event = None):
        #read has a timeout of 1 sec
        while True:
            byte = self.file.read()
            #print("0x"+byte.hex())
            if byte == b'\xc3': # init seq
                size_ = self.file.read()
                if size_ == b'':
                    return None
                size = ord(size_)
                data = self.file.read(size)
                last = self.file.read()
                if last == b'\xb4': #end seq
                    break
                else:
                    #print("ERR - Encapsulation - Wrong last char: 0x{}".format(last.hex()))
                    return None
            if stop_event != None and stop_event.is_set():
                return None
        return bytearray(data)                 
        
    def cancel_read(self):
        self.file.cancel_read()

    def close(self):       
        self.file.close()  
  
class InputFile(object):

    def __init__(self, bin_file=None):
        try:
            print(bin_file)       
            self.file = open(bin_file, 'rb') 
            
            print(str(self.file) + " open")
        except:
            print(str(self.file) + " not open")
            raise
            
    def read_binary_trace(self):
        bin_trace = None
        while True:
            try:
                byte = self.file.read(1)
                if byte == b'':
                    break
                if byte == b'\xc3':
                    # initial sequence found
                    size = ord(self.file.read(1))
                    if size is None:
                        break
                    data = self.file.read(size)
                    if data is None:
                        break
                    last = self.file.read(1)
                    if last is None:
                        break
                    if last == b'\xb4':
                        bin_trace = bytearray(data)
                        break
                    else:
                        print("ERR - Encapsulation - Wrong last char: {}".format(last.hex()))
                        return None
            except KeyboardInterrupt:
                break
        return bin_trace

    def close(self):       
        self.file.close()

class OutputFile(object):

    def __init__(self, path = None, prefix = None):
        if prefix is not None:
            filename = prefix + "_" + time.strftime("%Y%m%d_%H%M") + ".txt"
        else:    
            filename = time.strftime("%Y%m%d_%H%M") + ".txt"
        if path != None:
            filename = path+filename
        self.file = open(filename, 'w')    
            
    def write_string(self, string, is_echo=False):
        self.file.write(string)
        self.file.write("\n")
        if is_echo == True:
            print(string)

    def close(self):       
        self.file.close()        
      
class XMLFile(object):

    def __init__(self, filename):
        fn = os.path.dirname(os.path.realpath(__file__)) + "\\" + filename
        with open(fn, 'rt') as f:
            self.tree = ElementTree.parse(f)    
            
    def find_readable_string(self, module, trace):
        for xml_node in self.tree.findall('.//TTRACE_DEF_MOD'):
            mode_id = xml_node.find('ModId')
            if (mode_id is not None) and (mode_id.text == str(module)): 
                for xml_node in self.tree.findall('.//TTRACE_DEF_FIELD'):
                    trace_id = xml_node.find('TraceId')
                    if (trace_id is not None) and (trace_id.text == str(trace)):
                        # Return the human readable trace                                            
                        trace_string = xml_node.find('TraceString')    
                        return trace_string.text   
                        
        return None         

class TraceDecoder(object):

    def __init__(self, config):
        self.frag_buf = bytearray()
        self.wait_next_trace = False
        self.xml_list = []
        self.xml_list.append(XMLFile(config.get("xml", "phy_data"))) 
        self.xml_list.append(XMLFile(config.get("xml", "phy_debug")))
        self.xml_list.append(XMLFile(config.get("xml", "phy_info")))
        self.xml_list.append(XMLFile(config.get("xml", "rtei_debug")))
        self.xml_list.append(XMLFile(config.get("xml", "rtei_info")))
        self.xml_list.append(XMLFile(config.get("xml", "mac_data")))
        self.xml_list.append(XMLFile(config.get("xml", "mac_debug")))
        self.xml_list.append(XMLFile(config.get("xml", "mac_info")))
        self.xml_list.append(XMLFile(config.get("xml", "adp_data")))
        self.xml_list.append(XMLFile(config.get("xml", "adp_debug")))
        self.xml_list.append(XMLFile(config.get("xml", "adp_info")))   
        self.xml_list.append(XMLFile(config.get("xml", "boot_debug")))
        self.xml_list.append(XMLFile(config.get("xml", "boot_info"))) 
        self.xml_list.append(XMLFile(config.get("xml", "g3lib_info")))  
        self.xml_list.append(XMLFile(config.get("xml", "rtewdg_debug")))           
        self.xml_list.append(XMLFile(config.get("xml", "hostif")))   
        self.xml_list.append(XMLFile(config.get("xml", "hostif_data")))    
        self.xml_list.append(XMLFile(config.get("xml", "ip")))        
        self.xml_list.append(XMLFile(config.get("xml", "app")))
        self.xml_list.append(XMLFile(config.get("xml", "rf")))          
        self.global_timestamp = 0
        self.last_timestamp = 0
            
    def match_xml(self, module, trace):
        for xml in self.xml_list:
            trace_string = xml.find_readable_string(module, trace)   
            if trace_string is not None:
                return trace_string                           
            
        return "ModId " + str(module) + ", TraceId " + str(trace)       
        
    def print_buffer(self, buffer):
        string = ''.join('{:02x}'.format(x) for x in buffer)
        return string   
        
    def decode_trace(self, module, type, word):
        if type == 0:
            traceH = word[2] & 0x3F
            traceL = (word[1] >> 4) & 0x0F 
            trace = (traceH << 4) | traceL
            self.last_timestamp = self.global_timestamp + (word[1] & 0x0F) 
            return str(self.last_timestamp) + "," + self.match_xml(module, trace)
        if type == 1:
            traceH = word[2] & 0x3F
            traceL = (word[1] >> 4) & 0x0F 
            trace = (traceH << 4) | traceL
            self.last_timestamp = self.global_timestamp + (word[1] & 0x0F)
            byte = word[0]
            return str(self.last_timestamp) + "," + self.match_xml(module, trace) + ": 0x%02X" %byte 
        if type == 2:
            trace = word[2] & 0x3F
            data = (word[1] << 8) | word[0]
            return str(self.last_timestamp) + "," + self.match_xml(module, trace) + ": 0x%04X" % data
        if type == 3:
            traceH = word[2] & 0x3F
            traceL = (word[1] >> 4) & 0x0F 
            trace = (traceH << 4) | traceL
            sizeH = word[1] & 0x0F
            sizeL = word[0] 
            size = (sizeH << 8) | sizeL
            self.frag_buf.extend(word[4:])
            # if the trace is not completed, do not print the string immediately
            if (self.wait_next_trace is False):
                string = str(self.last_timestamp) + "," + self.match_xml(module, trace) + ": 0x" + self.print_buffer(self.frag_buf).upper()
                self.frag_buf = bytearray()
                return string
        return "" 

    def decode_timestamp(self, word):
        timestamp = ((word[3] & 0x0F) << 24) | (word[2] << 16) | (word[1] << 8) | word[0]   
        return timestamp
        
    def decode_version(self, word):
        trace_ver = word[0]   
        chip_ver = word[1]
        return "*** Trace vers. " + str(trace_ver) + ", Chip vers."         

    def decode_word(self, word):  
        if word == None:
            return ""

        # decode frag
        frag = (word[3] >> 7) & 0x01
        if frag == 1:
            self.wait_next_trace = True
        else:
            self.wait_next_trace = False

        # decode priority  
        prio = (word[3] >> 5) & 0x03

        if prio < 3:
            module = word[3] & 0x1F
            type = (word[2] >> 6) & 0x03
            return self.decode_trace(module, type, word)
        elif prio == 3:
            type = word[3] & 0x10
            if type == 0:
                self.global_timestamp = self.decode_timestamp(word) 
                self.last_timestamp = self.global_timestamp
                return ""
            elif type == 1:
                return self.decode_version(word)
            else:
                return "ERR - wrong type (prio 3): " + str(type)
        else:
            return "ERR - wrong prio: " + str(prio)

class G3TraceParserCOM(object):

    def __init__(self, com_port = None, out_path = None):
        self.thread_stop_ev = threading.Event()
        self.thread_stop_ev.clear()
        self.ser = SerialPort(com_port)
        self.out_path = out_path

    def start_trace_parser_com_asynch(self, is_echo = True, out_file_prefix = None):

        self.trace_parser_thread = threading.Thread(target=self.run_trace_parser_com, args=(is_echo, out_file_prefix))
        self.trace_parser_thread.name = "run_trace_parser_com " + str(self.ser.file.port)
        self.trace_parser_thread.start()

    def stop_trace_parser_com_asynch(self):
        self.thread_stop_ev.set()
        self.ser.cancel_read()
        self.trace_parser_thread.join()

    def run_trace_parser_com(self, is_echo = True, out_file_prefix = None):
        config = configparser.ConfigParser()
        fn = config.read(CONFIGURATION_FILE)

        binary_trace = TraceDecoder(config)
        output = OutputFile(self.out_path,  (out_file_prefix+"_" if out_file_prefix else "")+self.ser.file.port)
        
        while not self.thread_stop_ev.is_set():
            try:
                word = self.ser.read_binary_trace(self.thread_stop_ev)
                string = binary_trace.decode_word(word)
                if (string != ""):
                    string = time.strftime("%Y-%m-%d,%H:%M:%S,") + string
                    if (output is not None):
                        output.write_string(string, is_echo)
                    else:
                        print(string)
            except KeyboardInterrupt:
                break

        output.close()
        self.ser.close()

class G3TraceParserFile(object):

    def __init__(self, bin_file = None):
        self.thread_stop_ev = threading.Event()
        self.bin_file = bin_file
        self.out_path = None

    def run_trace_parser_file(self, is_echo = True, out_file_prefix = None):
        config = configparser.ConfigParser()
        fn = config.read(CONFIGURATION_FILE)

        binary_trace = TraceDecoder(config)
        try:
            in_f = InputFile(bin_file=self.bin_file)
        except:
            print("Input {} Files do not exist".format(self.bin_file))
            return
        output = OutputFile(self.out_path, (out_file_prefix+"_" if out_file_prefix else "")+self.bin_file)

        while True:
            word = in_f.read_binary_trace()
            if word is None:
                break
            else:
                string = binary_trace.decode_word(word)
                if (string != ""):
                    if (output is not None):
                        output.write_string(string, is_echo)        
        output.close()
    
if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument("--com", help = "run trace parser on serial port")
    parser.add_argument("--f", help = "run trace parser on binary file")
    args = parser.parse_args()

    if args.com is not None:    
        tp = G3TraceParserCOM(args.com)
        tp.run_trace_parser_com()
    elif args.f is not None:   
        tp = G3TraceParserFile(args.f) 
        tp.run_trace_parser_file()
    else:
        print("Error, must specify com port or file")
        parser.print_help()