import argparse

if __name__ == "__main__":
    # Define help strings
    program_desc_str    = "Split a G3 Trace log in text format into shorter files, " + \
                          "optionally filtering lines based on content"
    program_epilog      = "Parse the <in_file> file, producing a sequence of " + \
                          "files named <OUT_FILE>.000.txt, <OUT_FILE>.001.txt (etc.), containing only the  " + \
                          "lines in <IN_FILE> were there is the occurence of <FILTER> string. " + \
                          "All the output files but the last one will have exactly <LINE> lines. " +\
                          "Note that multiple --filter arguments can be provided, in that case the lines " +\
                          "containing (at least) one of the specified <FILTER> strings will be written"
    in_file_help_str    = "Trace (text) input file" 
    out_file_help_str   = "Output text file(s) without extension (OUT_FILE.000.txt, " + \
                          "OUT_FILE.001.txt and so on will be generated)"
    filter_help_str     = "only in_file lines containg one of the FILTER strings will be copied " + \
                          "to out_file(s) (multiple --filter instances allowed)"
    lines_help_str      =  "Max number of lines in each output file"
    
    # Set command line arguments
    parser = argparse.ArgumentParser(description=program_desc_str, epilog=program_epilog)
    parser.add_argument("in_file", help=in_file_help_str, type=str)
    parser.add_argument("--out_file", help=out_file_help_str, default="outfile", type=str)
    parser.add_argument("--filter", help=filter_help_str, type=str, action='append')
    parser.add_argument("--lines", help=lines_help_str,default=2000, type=int)
    # Get arguments
    args = parser.parse_args()
    # Store arguments to relevant variables
    in_file_name = args.in_file
    out_file_pattern = args.out_file
    filter = args.filter
    lines = args.lines

    with open(in_file_name, 'r') as in_file:
        name_counter = 0
        current_line = -1
        out_file = None
        for line in in_file:
            if current_line == -1:
                # Close the previous file (if any)
                if out_file != None:
                    out_file.close()
                # Create a new file
                out_file_name = out_file_pattern + ".{:03d}".format(name_counter) + ".txt"
                out_file = open(out_file_name, 'w')
                # Increment the file name counter
                name_counter = name_counter + 1
                # Set the number of lines in the current out file to 0 to start
                current_line = 0
            # Parse lines one by one
            if filter == None:
                # No filter, use all the lines
                out_file.writelines(line)
                current_line = current_line +1
            else:
                # Filtering strings present, use to filter
                for filter_string in filter:
                    if filter_string in line:
                        # Line contains the filter string
                        out_file.writelines(line)
                        current_line = current_line +1
                        # No need to check for other filters
                        break

            # Check if max lines numebr has been reached
            if current_line >= lines:
                # Trigger a new file to be created
                current_line = -1
        out_file.close()
                            
            
                