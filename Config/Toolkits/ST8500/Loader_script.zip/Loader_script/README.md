## Sample Commands

.\image_loader_st8500.exe --port COM18 --pe imgs\ST8500_PRIME_1_4_CPU_v665.img --rte imgs\ST8500_PRIME_1_4_RT_v6232.img
.\image_loader_st8500.exe --port COM18 --pe imgs\ST8500_G3_v1390B5EC_4.4.9.img --rte imgs\STARCOM_G3_RT_FW_r1_6rc2_BA_key0.img
.\image_loader_st8500.exe --port COM18 --hi_boot
.\image_loader_st8500.exe --port COM18 --get_running_protocol