#/*********************************************************************
#*                SEGGER MICROCONTROLLER SYSTEME GmbH                 *
#*        Solutions for real time microcontroller applications        *
#**********************************************************************
#*                                                                    *
#*        (C) 2004-2019    SEGGER Microcontroller Systeme GmbH        *
#*                                                                    *
#*      Internet: www.segger.com    Support:  support@segger.com      *
#*                                                                    *
#**********************************************************************
#----------------------------------------------------------------------
#File        : __init__.py
#Purpose     : Makes python treat the jlinksdk directory as a package.
#---------------------------END-OF-HEADER------------------------------
#*/

from .jlink import *