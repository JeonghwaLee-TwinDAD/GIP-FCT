#/*********************************************************************
#*               (c) SEGGER Microcontroller GmbH                      *
#*                        The Embedded Experts                        *
#*                           www.segger.com                           *
#**********************************************************************
#
#-------------------------- END-OF-HEADER -----------------------------
#
#Purpose: Implementation of the jlink module for the jlinksdk python package
#Literature:
#  [1]  Python 3 Online Documentation https://docs.python.org/3/library/index.html
#  [2]  J-Link SDK Manual (UM08002)
#
#Additional information:
#  -
#*/

from .jlinkConst import * # Used to setup structs and struct like classes. Similar to JLINKARM_Const.h
from ctypes import *      # Used to interactions with the J-Link DLL
import sys
import os
import platform           # Used to determine the current OS
import struct             # Used to determine the current OS architecture
import numpy              # Used to convert C type arrays to python lists

#/*********************************************************************
#*
#*       "Private" module variables
#*
#**********************************************************************
#*/
cdeclDLL   = None
stdcallDLL = None

#/*********************************************************************
#*
#*       Public module variables
#*
#**********************************************************************
#*/
DLLIsLoaded = False
NULL        = None

#/*********************************************************************
#*
#*       Private functions
#*
#**********************************************************************
#*/
#/*********************************************************************
#*
#*       __Log()
#*
#*  Function description
#*    Send a message to stdout and flushes it instantly
#*
#*  Parameters
#*    sOutput  - String to be sent to stdout
#*/
def __Log(sOutput):
  sys.stdout.write(sOutput)
  sys.stdout.flush()         # Make sure that terminal flushes its buffer also if there is no newline character in the string to output

#/*********************************************************************
#*
#*       __GetArch()
#*
#*  Function description
#*    Returns the architecture of the python interpreter running this script.
#*
#*  Return value
#*    32   -  32bit python interpreter
#*    64   -  64bit python interpreter
#*/
def __GetArch():
  return struct.calcsize("P") * 8

#/*********************************************************************
#*
#*       __GetPathLatestDLLWin()
#*
#*  Function description
#*    Returns Path and version of most recent JLink Software Dir.
#*
#*  Return value
#*    32   -  32bit python interpreter
#*    64   -  64bit python interpreter
#*/
def __GetPathLatestDLLWin():
  import errno  # Do windows only imports.
  import winreg # Do windows only imports.

  RegKeyName     = "SOFTWARE\\SEGGER\\J-Link"
  sLatestInstDir = None
  ProcArch       = os.environ['PROCESSOR_ARCHITECTURE'].lower()
  try:
    ProcArch64 = os.environ['PROCESSOR_ARCHITEW6432'].lower()
  except:
    ProcArch64 = ""
  if ProcArch == 'x86' and not ProcArch64:
    Flag = 0
  elif ProcArch == 'x86' or ProcArch == 'amd64':
    Flag = winreg.KEY_WOW64_64KEY
  else:
    raise Exception("OS architecture not supported: %s" % ProcArch)
  Flag |= winreg.KEY_READ
  try:
    Key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, RegKeyName, 0, Flag)
  except:
    Exception("Failed to autodetect DLL.")
  CurVersion = ""
  for i in range(0, winreg.QueryInfoKey(Key)[0]):
    sKeyName = winreg.EnumKey(Key, i)
    if (sKeyName > CurVersion):
      sKey = winreg.OpenKey(Key, sKeyName)
      try:
        InstPath = winreg.QueryValueEx(sKey, 'InstallPath')[0]
        print(sKeyName + " - " + InstPath)
        sLatestInstDir = InstPath
      except OSError as e:
        if e.errno == errno.ENOENT: # DisplayName doesn't exist in this skey? => Pass.
          pass
      finally:
        sKey.Close()
        CurVersion = sKeyName
  return sLatestInstDir

#/*********************************************************************
#*
#*       __AutodetectDLL()
#*
#*  Function description
#*    Autodetects the DLL to use.
#*
#*  Return value
#*
#*/
def __AutodetectDLL():
  OSArch   = __GetArch()
  ActiveOS = platform.system()
  #
  # Determine DLL Name
  #
  if (ActiveOS == 'Windows'):     # Running Windows?
    if (OSArch == 32):
      sDLLName = "JLinkARM.dll"
    elif (OSArch == 64):
      sDLLName = "JLink_x64.dll"
    else:
      raise JLinkError("Unsupported OS architecture: %d", OSArch)
  elif (ActiveOS == 'Linux'):     # Running Linux?
    sDLLName = "libjlinkarm.so"
  elif (ActiveOS == 'Darwin'):    # Running macOS?
    sDLLName = "libjlinkarm.dylib"
  else:
    raise JLinkError("Unsupported OS: %s", ActiveOS)
  #
  # To autodetect the DLL we look for it (in order of importance) in:
  #   1) Application execution dir (default for most applications).
  #   2) One dir above execution dir (default for SDK).
  #   3) Default inst dir of the J-Link Software Pack:
  #     i)  Windows: Latest version present in the registry.
  #     ii) Linux + macOS: Default inst dir.
  #
  if os.path.isfile(os.path.join("./", sDLLName)):     # See 1)
    return os.path.join("./", sDLLName)
  if os.path.isfile(os.path.join("./../", sDLLName)):  # See 2)
    return os.path.join("./../", sDLLName)
  #
  # See 3)
  #
  sDLLDir = None
  if (ActiveOS == 'Windows'):
    sDLLDir = __GetPathLatestDLLWin()
  elif (ActiveOS == 'Linux'):     # Running Linux?
    sDLLDir = os.path.join('/', 'opt', 'SEGGER', 'JLink')  # "JLink" is a symlink that points to the latest installed version
  elif (ActiveOS == 'Darwin'):    # Running macOS?
    #
    # On MacOS the J-Link SDK is shipped as a .dmg file which results in the SDK being a mounted device.
    # Mounted devices (aka. volumes) are listed as directories under /Volumes/
    #
    os.chdir("/Volumes/")
    aVolumes = os.listdir(".")
    MostRecentVolume = ""
    for Volume in aVolumes:
      if (Volume.startswith("JLinkSDK_MacOSX_")):         # Later version found? => Remember volume
        if (Volume > MostRecentVolume):
          MostRecentVolume = Volume
    if(MostRecentVolume != ""):
      sDLLDir = os.path.abspath(MostRecentVolume)
  #
  # Build path to DLL
  #
  if (sDLLDir == None): # No DLL found? => Error.
    raise JLinkError("Failed to autodetect DLL.")
  sDLLPath = os.path.join(sDLLDir, sDLLName)
  return sDLLPath

#/*********************************************************************
#*
#*       __SetupDLLFuncs()
#*
#*  Function description
#*    Loads the J-Link DLL.
#*
#*  Parameters
#*    cdeclDLL   - CDECL instance of the DLL.
#*    stdcallDLL - STDCALL instance of the DLL.
#*/
def __SetupDLLFuncs(cdeclDLL, stdcallDLL):
  #
  # Inform the ctypes package about the different functions return types.
  # For functions that are not explictly set here, "int" is assumed as return value.
  #
  cdeclDLL.JLINKARM_Open.restype           = c_char_p
  cdeclDLL.JLINKARM_ReadReg.restype        = c_uint32
  cdeclDLL.JLINKARM_ReadRegs.restype       = c_int
  cdeclDLL.JLINKARM_SelectIP.restype       = c_char
  cdeclDLL.JLINKARM_WriteReg.restype       = c_char
  cdeclDLL.JLINKARM_WriteRegs.restype      = c_int
  #
  # Inform the ctypes package about the expected types for different functions arguments.
  # For functions that are not explictly set here, the ctypes package guesses the correct type.
  #
  cdeclDLL.JLINKARM_EMU_SelectIP.argtypes  = (c_char_p, c_uint32, POINTER(c_uint16))
  cdeclDLL.JLINKARM_ReadMemU16.argtypes    = (c_uint32, c_uint32, POINTER(c_uint16), c_char_p)
  cdeclDLL.JLINKARM_ReadMemU32.argtypes    = (c_uint32, c_uint32, POINTER(c_uint32), c_char_p)
  cdeclDLL.JLINKARM_ReadMemU64.argtypes    = (c_uint32, c_uint32, POINTER(c_uint64), c_char_p)
  cdeclDLL.JLINKARM_ReadReg.argtypes       = (c_uint32, )
  cdeclDLL.JLINKARM_ReadRegs.argtypes      = (POINTER(c_uint32), POINTER(c_uint32), c_char_p, c_uint32)
  cdeclDLL.JLINKARM_SelectIP.argtypes      = (c_char_p, c_int)
  cdeclDLL.JLINKARM_WriteReg.argtypes      = (c_uint32, c_uint32)
  cdeclDLL.JLINKARM_WriteRegs.argtypes     = (POINTER(c_uint32), POINTER(c_uint32), c_char_p, c_uint32)
  cdeclDLL.JLINKARM_WriteU16.argtypes      = (c_uint32, c_uint16)
  cdeclDLL.JLINKARM_WriteU32.argtypes      = (c_uint32, c_uint32)
  cdeclDLL.JLINKARM_WriteU64.argtypes      = (c_uint32, c_uint64)

#/*********************************************************************
#*
#*       Public functions
#*
#**********************************************************************
#*/

#/*********************************************************************
#*
#*       LoadDLL()
#*
#*  Function description
#*    Loads the J-Link DLL.
#*
#*  Parameters
#*    sPath   -  (optional) Path to load the DLL from. If this parameter is not passed,
#*                          this function tries to find and load the newest installed
#*                          version of the J-Link DLL.
#*/
def LoadDLL(sPath = None):
  global cdeclDLL
  global stdcallDLL
  global DLLIsLoaded

  if (DLLIsLoaded):
    return
  WorkingDir = os.getcwd()
  sDLLPath = ""
  ActiveOS = platform.system()

  if (sPath == None):                                   # No direct path selected? => Try to autodetect DLL.
    sDLLPath = __AutodetectDLL()
  else:                                                 # Use path to look for DLL from parameter?
    sDLLPath = sPath
  #
  # Load DLL
  #
  os.chdir(WorkingDir)
  r = os.path.isfile(sDLLPath)                          # Check if the DLL file exists
  if (r == False):                                      # DLL file does not exist? => Error
    raise JLinkError("Could not find J-Link DLL.")
  try:
    cdeclDLL   = cdll.LoadLibrary(sDLLPath)             # Load DLL for using functions with cdecl calling convention
    if (ActiveOS == "Windows"):                         # Running on windows? => Load DLL for using functions with stdcall calling convention
      stdcallDLL = windll.LoadLibrary(sDLLPath)
    else:                                               # Running on Linux/ macOS?
      stdcallDLL = cdeclDLL
  except Exception as e:
    raise JLinkError("Failed to load J-Link DLL: " + str(e))
  __SetupDLLFuncs(cdeclDLL, stdcallDLL)                 # initializes the DLL functions to be known by the pyhton interpreter
  #
  # Mark DLL as initialized.
  #
  DLLIsLoaded = True
  return

#/*********************************************************************
#*
#*       GetCDLLInst()
#*
#*  Function description
#*    Returns handle to a loaded instance of the J-Link DLL for calling functions using the standard "cdecl" calling convention.
#*
#*  Return value
#*    <cDLLInst>
#*/
def GetCDLLInst():
  global DLLIsLoaded

  if (DLLIsLoaded == False):
    raise JLinkError("J-Link DLL is not loaded.")
  return cdeclDLL

#/*********************************************************************
#*
#*       GetWinDLLInst()
#*
#*  Function description
#*    Returns handle to a loaded instance of the J-Link DLL for calling functions using the "stdcall" calling convention.
#*
#*  Return value
#*    <cDLLInst>
#*/
def GetWinDLLInst():
  if (DLLIsLoaded == False):
    raise JLinkError("J-Link DLL is not loaded.")
  return stdcallDLL

#/*********************************************************************
#*
#*       ToCStr()
#*
#*  Function description
#*    Converts a python string to a C string (char*)
#*
#*  Parameters
#*    s   -  Python string to convert
#*
#*  Return value
#*    C char pointer of type c_char_p
#*/
def ToCStr(s):
  s = s.encode('utf-8')      # Encode python string to bytes
  return c_char_p(s)         # Convert bytes to char pointer for passing strings to DLL functions

#/*********************************************************************
#*
#*       PrintMem()
#*
#*  Function description
#*    Prints a byte array
#*
#*  Parameters
#*    ab      - byte array
#*    Len     - number of bytes that should be compared
#*    AddrOff - (optional) Address offset to be displayed. 0 by default.
#*/
def PrintMem(ab, Len, AddrOff = 0x0):
  #
  # Convert bytes() to bytearray() to access and compare single bytes individually
  #
  ab = bytearray(ab)
  iByte = 0
  #
  # For the first line, print the byte that each column represents as follows:
  # 0 1 2 3 ... D E F
  s = "\n              0  1  2  3  4  5  6  7  8  9  A  B  C  D  E  F\n"
  __Log(s)
  #
  # Print differences
  #
  NumLines = int(Len / 16)
  for y in range(0, NumLines):
    __Log("0x%08X = " % AddrOff)
    AddrOff += 16
    for x in range (0, 16):
      iByte = y * 16 + x
      s = "%02X " % ab[iByte]
      __Log(s)
    __Log("\n")
  #
  # Len was not a multiple of 16?
  # Print leftover bytes
  #
  NumLeft = Len % 16
  if (NumLeft > 0):
    __Log("0x%08X = " % AddrOff)
    for x in range (0, NumLeft):
      s = "%02X " % ab[iByte]
      __Log(s)
      iByte += 1
    __Log("\n")

#/*********************************************************************
#*
#*       JLink
#*
#*  Class description
#*    Instances of this class are used to load the DLL and call API functions.
#*
#**********************************************************************
#*/
class JLink():
  #
  # Class for FlashDownload context manager
  #
  class FlashDownload():
    def __enter__(self):                         # Called on entering a flash download context manager
      cdeclDLL.JLINKARM_BeginDownload(0)
    def __exit__(self, type, value, traceback):  # Called on leaving a flash download context manager
      r = cdeclDLL.JLINKARM_EndDownload()
      sErr = None
      if (r < 0):                            # Error occured?
        sErr = "Flash download failed."
      if (r == -2):                          # Compare failed?
        sErr += " Compare failed."
      elif (r == -3):                        # Program/ erase failed?
        sErr += " Program or erase failed."
      elif (r == -4):                        # Verify failed?
        sErr += " Verify failed."
      if (sErr):
        raise JLinkError(sErr)
  #
  # Constructor
  #
  def __init__(self, sDLLPath = None):  # Constructor
    LoadDLL(sDLLPath)

  #/*********************************************************************
  #*
  #*       API Function wrappers
  #*
  #**********************************************************************
  #*/

  #/*********************************************************************
  #*
  #*       Basic functions
  #*
  #**********************************************************************
  #*/

  #/*********************************************************************
  #*
  #*       Open()
  #*
  #*  Function description
  #*    Connects to a J-Link.
  #*
  #*  Parameters
  #*    HostIF   -  (optional) Host interface, see HOST_IF class
  #*    SN       -  (optional) S/N of emulator
  #*    IP       -  (optional) IP of emulator
  #*/
  def Open(self, HostIF = None, SN = None, sIP = None, Port = 0):
    if (type(HostIF) == str):
      HostIF = HostIF.upper()
    DummyPort = c_uint16(0)
    r = 0
    if   (HostIF == HOST_IF.TCPIP or
          HostIF == "IP"):                        # Connect via IP?
      if (SN):                                    # To a specific SN?
        cdeclDLL.JLINKARM_EMU_SelectIPBySN(SN)
      elif (sIP):                                 # To a specific IPAddr or Host?
        r = cdeclDLL.JLINKARM_SelectIP(sIP.encode('utf-8'), int(Port))
        r = ord(r)
        if (r == 1):                               
          r = -1
      else:                                       # No specific SN?
        r = cdeclDLL.JLINKARM_EMU_SelectIP(NULL, 0, DummyPort)
    elif (HostIF == HOST_IF.USB or
          HostIF == "USB"):                       # Connect via USB?
      if (SN):                                    # To a specific SN?
        r = cdeclDLL.JLINKARM_EMU_SelectByUSBSN(SN)
    elif (HostIF):                                # Invalid HOST IF?
      raise JLinkError("Unsupported Host IF: " + str(HostIF))
    if (r < 0):                                  # Failed to select an emulator?
      raise JLinkError("Failed to select emulator.")
    cstr = cdeclDLL.JLINKARM_Open()
    if (cstr):                    # Failed to connect to J-Link? => Error
      s = cstr.decode('utf-8')
      raise JLinkError(s)

  #/*********************************************************************
  #*
  #*       Close()
  #*
  #*  Function description
  #*    Disconnects from a J-Link.
  #*/
  def Close(self):
    cdeclDLL.JLINKARM_Close()

  #/*********************************************************************
  #*
  #*       Connect()
  #*
  #*  Function description
  #*    Connects to a target device
  #*
  #*  Parameters
  #*    sDevice    - (optional) Name of the device to connect to
  #*    TIF        - (optional) Target interface
  #*    TIFSpeed   - (optional) Target interface speed in kHz
  #*/
  def Connect(self, sDevice = "", TIF = None, TIFSpeed = SPEED.AUTO):
    s = "device = %s" % (sDevice)
    r, sErr = self.Exec(s)
    if ((r != 0) or (sErr != None)):
      raise JLinkError("Failed to set device name.")
    if (TIF != None):
      cdeclDLL.JLINKARM_TIF_Select(TIF)
      cdeclDLL.JLINKARM_SetSpeed(TIFSpeed)
    r = cdeclDLL.JLINKARM_Connect()
    if (r != 0):
      raise JLinkError("Failed to connect to target.")

  #/*********************************************************************
  #*
  #*       Go()
  #*
  #*  Function description
  #*    Restarts the CPU core after it has been halted.
  #*/
  def Go(self):
    cdeclDLL.JLINKARM_Go()

  #/*********************************************************************
  #*
  #*       Halt()
  #*
  #*  Function description
  #*    Halts the core.
  #*/
  def Halt(self):
    r = cdeclDLL.JLINKARM_Halt()
    if (r == 1):  # Failed to halt core? => Error
      raise JLinkError("Failed to halt core.")

  #/*********************************************************************
  #*
  #*       Exec()
  #*
  #*  Function description
  #*     Executes the given command string.
  #*
  #*  Return value
  #*    [1]:
  #*      Return value of the executed command.
  #*    [2]:
  #*       == None: No error occured.
  #*       != None: Error string.
  #*/
  def Exec(self, sExec = ""):
    sErr    = None
    Len     = 512
    abError = bytes([0x00] * Len)
    r = cdeclDLL.JLINKARM_ExecCommand(ToCStr(sExec), abError, Len)
    if (abError[0] != 0):
      sErr = abError.decode('utf-8').replace("\0", "")
    return r, sErr

  #/*********************************************************************
  #*
  #*       IsConnected()
  #*
  #*  Function description
  #*    Determines if connected to a target device.
  #*
  #*  Return value
  #*    True / False
  #*/
  def IsConnected(self):
    r = cdeclDLL.JLINKARM_IsConnected()
    if (r == 0):
      return False
    else:
      return True

  #/*********************************************************************
  #*
  #*       IsHalted()
  #*
  #*  Function description
  #*    Determines if the core is currently halted.
  #*
  #*  Return value
  #*    True / False
  #*/
  def IsHalted(self):
    r = cdeclDLL.JLINKARM_IsHalted()
    if (r < 0):
      raise JLinkError("Failed to check whether ARM core is halted.")
    elif (r == 0):
      return False
    else:
      return True

  #/*********************************************************************
  #*
  #*       IsOpen()
  #*
  #*  Function description
  #*    Determines if a connection to a J-Link is open.
  #*
  #*  Return value
  #*    True / False
  #*/
  def IsOpen(self):
    r = cdeclDLL.JLINKARM_IsOpen()
    if (r == 0):
      return False
    else:
      return True

  #/*********************************************************************
  #*
  #*       GetEmuList()
  #*
  #*  Function description
  #*    Returns the list of available emulators.
  #*
  #*  Return value
  #*    <Array of CONNECTION_INFO instances>
  #*/
  def GetEmuList(self, USB = True, TCPIP = True):
    HostIFs = 0
    if (USB):
      HostIFs |= HOST_IF.USB
    if (TCPIP):
      HostIFs |= HOST_IF.TCPIP
    NumEmus = cdeclDLL.JLINKARM_EMU_GetList(HostIFs, NULL, 0)
    aInfo  = []
    aCInfo = []
    if (NumEmus > 0):
      aCInfo   = (C_CONNECTION_INFO * NumEmus)()
      cdeclDLL.JLINKARM_EMU_GetList(HostIFs, aCInfo, NumEmus)
    elif (NumEmus < 0):
      raise JLinkError("Failed to retrieve list of emulators.")
    for i in aCInfo:
      Info = CONNECTION_INFO()
      Info.SN         = i.SerialNumber
      Info.HostIF     = i.Connection
      Info.abIP       = bytearray(i.aIPAddr)
      Info.HWVersion  = i.HWVersion
      Info.abMACAddr  = bytearray(i.abMACAddr)
      Info.sProduct   = i.acProduct.decode('utf-8')
      Info.sNickname  = i.acNickName.decode('utf-8')
      Info.sFW        = i.acFWString.decode('utf-8')
      aInfo.append(Info)
    return aInfo

  #/*********************************************************************
  #*
  #*       GetDLLVersion()
  #*
  #*  Function description
  #*    Determines the version of the loaded DLL
  #*
  #*  Return value
  #*    DLL version as decimal number = [Mmmrr]
  #*/
  def GetDLLVersion(self):
    return cdeclDLL.JLINKARM_GetDLLVersion()

  #/*********************************************************************
  #*
  #*       GetDllVersionString()
  #*
  #*  Function description
  #*    Determines the version of the loaded DLL and returns it as python string.
  #*
  #*  Return value
  #*    DLL version as string = [M.mmr], e.g. 6.80a
  #*/
  def GetDllVersionString(self):
    DLLVersion = self.GetDLLVersion()
    vMaj = int(DLLVersion / 10000)
    vMin = int((DLLVersion % 10000) / 100)
    vRev = int(DLLVersion % 100)
    if (vRev == 0):
      sRev = ""
    else:
      sRev = str(chr(ord('a') + vRev - 1))
    sVersion = "%d.%d%s" % (vMaj, vMin, sRev)
    return sVersion

  #/*********************************************************************
  #*
  #*       GetEmuCaps()
  #*
  #*  Function description
  #*    Determins the Emulator capabilities
  #*
  #*  Return value
  #*    Emulator capabilities
  #*/
  def GetEmuCaps(self):
    return cdeclDLL.JLINKARM_GetEmuCaps()

  #/*********************************************************************
  #*
  #*       Configuration functions
  #*
  #**********************************************************************
  #*/

  #/*********************************************************************
  #*
  #*       ConfigJTAG()
  #*
  #*  Function description
  #*    Configures the JTAG scan chain
  #*
  #*  Parameters
  #*    IRPre     - Total length of instruction registers of all devices closer to TDI than the addressed ARM device
  #*    DRPre     - Total number of data bits closer to TDI than the addressed ARM device
  #*/
  def ConfigJTAG(self, IRPre, DRPre):
    cdeclDLL.JLINKARM_ConfigJTAG(IRPre, DRPre)

  #/*********************************************************************
  #*
  #*       GetIRLen()
  #*
  #*  Function description
  #*    This function retrieves the sum of the number of bits of the instruction registers of all devices in the JTAG scan chain
  #*
  #*  Return value
  #*    IRLen
  #*/
  def GetIRLen(self):
    return cdeclDLL.JLINKARM_GetIRLen()

  #/*********************************************************************
  #*
  #*       Reset functions
  #*
  #**********************************************************************
  #*/

  #/*********************************************************************
  #*
  #*       Reset()
  #*
  #*  Function description
  #*    This function performs a reset
  #*
  #*  Parameters
  #*    DoHalt              - (optional) True by default.
  #*    ResetType           - (optional) See <RESET_TYPE>. RESET_TYPE.NORMAL by default
  #*    ToggleRESET         - (optional) True by default.
  #*    ToggleTRST          - (optional) True by default.
  #*    Delay               - (optional) 0 by default.
  #*    SetInitRegsOnReset  - (optional) False by default.
  #*/
  def Reset(self, DoHalt = True, ResetType = RESET_TYPE.NORMAL, ToggleRESET = True, ToggleTRST = True, Delay = 0, SetInitRegsOnReset = False):
    cdeclDLL.JLINKARM_SetResetType(ResetType)
    cdeclDLL.JLINKARM_SetResetDelay(Delay)
    cdeclDLL.JLINKARM_SetInitRegsOnReset(SetInitRegsOnReset)
    if (ToggleRESET):
      v = 1
    else:
      v = 0
    cdeclDLL.JLINKARM_ResetPullsRESET(v)
    if (ToggleTRST):
      v = 1
    else:
      v = 0
    cdeclDLL.JLINKARM_ResetPullsTRST(v)
    r = 0
    if (DoHalt):                       # Default Reset?
      r = cdeclDLL.JLINKARM_Reset()
      if (r < 0):
        raise JLinkError("Failed to reset target device.")
    else:
       cdeclDLL.JLINKARM_ResetNoHalt()

  #/*********************************************************************
  #*
  #*       Reset()
  #*
  #*  Function description
  #*    This function resets the TAP controller via TRST
  #*/
  def ResetTAP(self):
    cdeclDLL.JLINKARM_ResetTRST()

  #/*********************************************************************
  #*
  #*       Memory functions (read)
  #*
  #**********************************************************************
  #*/

  #/*********************************************************************
  #*
  #*       GetMemZones()
  #*
  #*  Function description
  #*    This function retrieves a list of memory zones for the connected target.
  #*
  #*  Return value
  #*    <Array of MEM_ZONE_INFO instances>
  #*/
  def GetMemZones(self):
    NumZones = stdcallDLL.JLINK_GetMemZones(NULL, 0)
    aInfo    = []
    aCInfo   = []
    if (NumZones > 0):
      aCInfo   = (C_MEM_ZONE_INFO * NumZones)()
      stdcallDLL.JLINK_GetMemZones(aCInfo, NumZones)
    elif (NumZones < 0):
      raise JLinkError("Failed to retrieve list of memory zones.")
    for i in aCInfo:
      Info = MEM_ZONE_INFO()
      Info.sDesc    = i.sDesc.decode('utf-8')
      Info.sName    = i.sName.decode('utf-8')
      Info.VirtAddr = i.VirtAddr
    return aInfo

  #/*********************************************************************
  #*
  #*       ReadMem()
  #*
  #*  Function description
  #*    This function reads memory from the target device.
  #*
  #*  Parameters
  #*    Addr         - Address to read from
  #*    NumBytes     - Number of bytes to read
  #*    AccessWidth  - (optional) Access width to use.
  #*    sZone        - (optional) Memory zone to use.
  #*
  #*  Return value
  #*    NumBytesRead, <Array of read bytes>
  #*/
  def ReadMem(self, Addr, NumBytes, AccessWidth = 0, sZone = None):
    abRead = bytes([0xFF] * NumBytes)
    if (sZone):
      NumBytesRead = stdcallDLL.JLINK_ReadMemZonedEx(Addr, NumBytes, abRead, AccessWidth, ToCStr(sZone))
    else:
      NumBytesRead = cdeclDLL.JLINKARM_ReadMemEx(Addr, NumBytes, abRead, AccessWidth)
    if (NumBytesRead < 0):  # Error occured? => throw Exception
      raise JLinkError("Failed to read memory from target.")
    return NumBytesRead, abRead

  #/*********************************************************************
  #*
  #*       ReadMemIndirect()
  #*
  #*  Function description
  #*    This function reads memory from the target system.
  #*
  #*  Parameters
  #*    Addr         - Address to read from
  #*    NumBytes     - Number of bytes to read
  #*
  #*  Return value
  #*    NumBytesRead, <Array of read bytes>
  #*/
  def ReadMemIndirect(self, Addr, NumBytes):
    abRead = bytes([0xFF] * NumBytes)
    NumBytesRead = cdeclDLL.JLINKARM_ReadMemIndirect(Addr, NumBytes, abRead)
    if (NumBytesRead < 0):  # Error occured? => throw Exception
      raise JLinkError("Failed to read memory from target.")
    return NumBytesRead, abRead

  #/*********************************************************************
  #*
  #*       ReadMemHW()
  #*
  #*  Function description
  #*    This function reads memory from the target system immediately from
  #*     the hardware without caching the memory contents
  #*
  #*  Parameters
  #*    Addr         - Address to read from
  #*    NumBytes     - Number of bytes to read
  #*
  #*  Return value
  #*    NumBytesRead, <Array of read bytes>
  #*/
  def ReadMemHW(self, Addr, NumBytes):
    abRead = bytes([0xFF] * NumBytes)
    NumBytesRead = cdeclDLL.JLINKARM_ReadMemHW(Addr, NumBytes, abRead)
    if (NumBytesRead < 0):  # Error occured? => throw Exception
      raise JLinkError("Failed to read memory from target.")
    return NumBytesRead, abRead

  #/*********************************************************************
  #*
  #*       ReadMemU8()
  #*
  #*  Function description
  #*    The function reads memory from the target system in units of bytes.
  #*
  #*  Parameters
  #*    Addr         - Address to read from
  #*    NumItems     - Number of items to read
  #*
  #*  Return value
  #*    NumBytesRead, <Array of read bytes>, <Array of status bytes>
  #*/
  def ReadMemU8(self, Addr, NumItems):
    abRead   = bytes([0xFF] * NumItems)
    abStatus = bytes([0xFF] * NumItems)
    NumBytesRead = cdeclDLL.JLINKARM_ReadMemU8(Addr, NumItems, abRead, abStatus)
    if (NumBytesRead < 0):  # Error occured? => throw Exception
      raise JLinkError("Failed to read memory from target.")
    return NumBytesRead, abRead, abStatus

  #/*********************************************************************
  #*
  #*       ReadMemU16()
  #*
  #*  Function description
  #*    The function reads memory from the target system in units of halfwords.
  #*
  #*  Parameters
  #*    Addr         - Address to read from
  #*    NumItems     - Number of items to read
  #*
  #*  Return value
  #*    NumBytesRead, <Array of read halfwords>, <Array of status bytes>
  #*/
  def ReadMemU16(self, Addr, NumItems):
    c_a16Read  = (c_uint16 * NumItems)()    # Create a ctypes array
    a16Read  = c_uint16 * NumItems
    abStatus = bytes([0xFF] * NumItems)
    NumItemsRead = cdeclDLL.JLINKARM_ReadMemU16(Addr, NumItems, c_a16Read, abStatus)
    a16Read = numpy.ndarray((NumItems, ), c_uint16, c_a16Read, order = 'C').tolist()  # Use NumPy to convert ctypes array to C list
    if (NumItemsRead < 0): # Error occured? => throw Exception
      raise JLinkError("Failed to read memory from target.")
    return NumItemsRead, a16Read, abStatus

  #/*********************************************************************
  #*
  #*       ReadMemU32()
  #*
  #*  Function description
  #*    The function reads memory from the target system in units of words.
  #*
  #*  Parameters
  #*    Addr         - Address to read from
  #*    NumItems     - Number of items to read
  #*
  #*  Return value
  #*    NumBytesRead, <Array of read words>, <Array of status bytes>
  #*/
  def ReadMemU32(self, Addr, NumItems):
    c_a32Read  = (c_uint32 * NumItems)()    # Create a ctypes array
    abStatus = bytes([0xFF] * NumItems)
    NumItemsRead = cdeclDLL.JLINKARM_ReadMemU32(Addr, NumItems, c_a32Read, abStatus)
    if (NumItemsRead < 0):  # Error occured? => throw Exception
      raise JLinkError("Failed to read memory from target.")
    a32Read = numpy.ndarray((NumItems, ), c_uint32, c_a32Read, order = 'C').tolist()  # Use NumPy to convert ctypes array to C list
    return NumItemsRead, a32Read, abStatus

  #/*********************************************************************
  #*
  #*       ReadMemU64()
  #*
  #*  Function description
  #*    The function reads memory from the target system in units of 64-bits.
  #*
  #*  Parameters
  #*    Addr         - Address to read from
  #*    NumItems     - Number of items to read
  #*
  #*  Return value
  #*    NumBytesRead, <Array of 64-bit values>, <Array of status bytes>
  #*/
  def ReadMemU64(self, Addr, NumItems):
    c_a64Read  = (c_uint64 * NumItems)()
    abStatus = bytes([0xFF] * NumItems)
    NumItemsRead = cdeclDLL.JLINKARM_ReadMemU64(Addr, NumItems, c_a64Read, abStatus)
    if (NumItemsRead < 0):  # Error occured? => throw Exception
      raise JLinkError("Failed to read memory from target.")
    a64Read = numpy.ndarray((NumItems, ), c_uint64, c_a64Read, order = 'C').tolist()  # Use NumPy to convert ctypes array to C list
    return NumItemsRead, a64Read, abStatus

  #/*********************************************************************
  #*
  #*       Memory functions (write)
  #*
  #**********************************************************************
  #*/

  #/*********************************************************************
  #*
  #*       WriteMem()
  #*
  #*  Function description
  #*    This function writes memory to the target device.
  #*
  #*  Parameters
  #*    Addr         - Address to read from
  #*    NumBytes     - Number of bytes to read
  #*    abWrite      - Array of bytes to write
  #*    AccessWidth  - (optional) Access width to use.
  #*    sZone        - (optional) Memory zone to use.
  #*  Return value
  #*    NumBytesWritten
  #*/
  def WriteMem(self, Addr, NumBytes, abWrite, AccessWidth = 0, sZone = None):
    abWrite = bytes(abWrite)                                                   # Convert to bytes() so ctypes can convert abWrite to a U8*
    if (sZone):
      NumBytesWritten = stdcallDLL.JLINK_WriteMemZonedEx(Addr, NumBytes, abWrite, AccessWidth, ToCStr(sZone))
    else:
      NumBytesWritten = cdeclDLL.JLINKARM_WriteMemEx(Addr, NumBytes, c_char_p(abWrite), AccessWidth)
    if (NumBytesWritten < 0):  # Error occured? => throw Exception
      raise JLinkError("Failed to write memory to target.")
    return NumBytesWritten

  #/*********************************************************************
  #*
  #*       WriteMemU8()
  #*
  #*  Function description
  #*    This function writes one single byte to the target device.
  #*
  #*  Parameters
  #*    Addr         - Address to read from
  #*    Data         - Byte to write
  #*/
  def WriteMemU8(self, Addr, Data):
    v = c_uint8(Data)
    r = cdeclDLL.JLINKARM_WriteU8(Addr, v)
    if (r != 0):  # Error occured? => throw Exception
      raise JLinkError("Failed to write memory to target.")

  #/*********************************************************************
  #*
  #*       WriteMemU16()
  #*
  #*  Function description
  #*    This function writes one halfword to the target device.
  #*
  #*  Parameters
  #*    Addr         - Address to read from
  #*    Data         - halfword to write
  #*/
  def WriteMemU16(self, Addr, Data):
    v = c_uint16(Data)
    r = cdeclDLL.JLINKARM_WriteU16(Addr, v)
    if (r != 0):  # Error occured? => throw Exception
      raise JLinkError("Failed to write memory to target.")

  #/*********************************************************************
  #*
  #*       WriteMemU32()
  #*
  #*  Function description
  #*    This function writes one word to the target device.
  #*
  #*  Parameters
  #*    Addr         - Address to read from
  #*    Data         - word to write
  #*/
  def WriteMemU32(self, Addr, Data):
    v = c_uint32(Data)
    r = cdeclDLL.JLINKARM_WriteU32(Addr, v)
    if (r != 0):  # Error occured? => throw Exception
      raise JLinkError("Failed to write memory to target.")

  #/*********************************************************************
  #*
  #*       WriteMemU64()
  #*
  #*  Function description
  #*    This function writes one 64-bit value to the target device.
  #*
  #*  Parameters
  #*    Addr         - Address to read from
  #*    Data         - 64-bit value to write
  #*/
  def WriteMemU64(self, Addr, Data):
    v = c_uint64(Data)
    r = cdeclDLL.JLINKARM_WriteU64(Addr, v)
    if (r != 0):  # Error occured? => throw Exception
      raise JLinkError("Failed to write memory to target.")

  #/*********************************************************************
  #*
  #*       EraseChip()
  #*
  #*  Function description
  #*    This function erases all flash sectors of the current device.
  #*
  def EraseChip(self):
    r = stdcallDLL.JLINK_EraseChip()
    if (r < 0):
      raise JLinkError("Failed to erase chip.")

  #/*********************************************************************
  #*
  #*       DownloadFile()
  #*
  #*  Function description
  #*    This function programs a given data file to a specified destination address.
  #*
  #*  Parameters
  #*    sPath     - Path to the data file
  #*    Addr      - Start address to be programmed to
  #*/
  def DownloadFile(self, sPath, Addr):
    r = stdcallDLL.JLINK_DownloadFile(ToCStr(sPath), Addr)
    if (r < 0):            # Error occured? => throw Exception
      raise JLinkError(r)

  #/*********************************************************************
  #*
  #*       System control functions
  #*
  #**********************************************************************
  #*/

  #/*********************************************************************
  #*
  #*       SetLogFile()
  #*
  #*  Function description
  #*    This function sets a log file for the DLL to use
  #*
  #*  Parameters
  #*    sPath     - Path to the log file
  #*/
  def SetLogFile(self, sPath):
    cdeclDLL.JLINKARM_SetLogFile(ToCStr(sPath))

  #/*********************************************************************
  #*
  #*       SetSpeed()
  #*
  #*  Function description
  #*    This function sets the speed of the target interface
  #*
  #*  Parameters
  #*    SpeedKHz     - TIFSpeed in kHz
  #*    SetAsMax     - (optional) Determines if the speed should be set as the maximum. False by default.
  #*/
  def SetSpeed(self, SpeedKHz, SetAsMax = False):
    cdeclDLL.JLINKARM_SetSpeed(SpeedKHz)
    if (SetAsMax):
      cdeclDLL.JLINKARM_SetMaxSpeed()

  #/*********************************************************************
  #*
  #*       GetSpeed()
  #*
  #*  Function description
  #*    This function determines the speed that the target interface is running on
  #*
  #*  Return value
  #*    <TIFSpeed> in kHz
  #*/
  def GetSpeed(self):
    return cdeclDLL.JLINKARM_GetSpeed()

  #/*********************************************************************
  #*
  #*       Debugging functions
  #*
  #**********************************************************************
  #*/

  #/*********************************************************************
  #*
  #*       WriteReg()
  #*
  #*  Function description
  #*    This function writes a single register of the target MCU.
  #*
  #*  Parameters
  #*    RegIndex    - Register index to write
  #*    Data        - Data to write
  #*/
  def WriteReg(self, RegIndex, Data):
    r = cdeclDLL.JLINKARM_WriteReg(RegIndex, Data)
    if (r == 1):
      raise JLinkError("Failed to write register")

  #/*********************************************************************
  #*
  #*       WriteRegs()
  #*
  #*  Function description
  #*    This function writes multiple registers of the target MCU at once.
  #*
  #*  Parameters
  #*    aRegIndex  - List of register indexes to write
  #*    aData      - List of values to write to registers
  #*
  #*  Return value
  #*    <Array of status bytes>
  #*/
  def WriteRegs(self, aRegIndex, aData):
    NumRegs = len(aRegIndex)
    c_aRegIndex = (c_uint32 * NumRegs)(*aRegIndex)  # Create a ctypes array
    c_a32Write  = (c_uint32 * NumRegs)(*aData)      # Create a ctypes array
    abStatus    = bytes([0xFF] * NumRegs)
    r = cdeclDLL.JLINKARM_WriteRegs(c_aRegIndex, c_a32Write, abStatus, NumRegs)
    if (r < 0):
      raise JLinkError("Failed to write multiple registers at once")
    return abStatus

  #/*********************************************************************
  #*
  #*       ReadReg()
  #*
  #*  Function description
  #*    This function reads a single register from the target MCU.
  #*
  #*  Parameters
  #*    RegIndex    - Register index to read
  #*
  #*  Return value
  #*    <Register contents>
  #*/
  def ReadReg(self, RegIndex):
    return cdeclDLL.JLINKARM_ReadReg(RegIndex)

  #/*********************************************************************
  #*
  #*       ReadRegs()
  #*
  #*  Function description
  #*    This function reads multiple register from the target MCU at once.
  #*
  #*  Parameters
  #*    aRegIndex  - List of register indexes to read
  #*
  #*  Return value
  #*    <Array of read values>, <Array of status bytes>
  #*/
  def ReadRegs(self, aRegIndex):
    NumRegs = len(aRegIndex)
    c_aRegIndex = (c_uint32 * NumRegs)(*aRegIndex)  # Create a ctypes array
    c_a32Read   = (c_uint32 * NumRegs)()            # Create a ctypes array
    abStatus    = bytes([0xFF] * NumRegs)
    r = cdeclDLL.JLINKARM_ReadRegs(c_aRegIndex, c_a32Read, abStatus, NumRegs)
    if (r < 0):
      raise JLinkError("Failed to read multiple registers at once")
    a32Read = numpy.ndarray((NumRegs, ), c_uint32, c_a32Read, order = 'C').tolist()  # Use NumPy to convert ctypes array to C list
    return a32Read, abStatus

  #/*********************************************************************
  #*
  #*       DisassembleInst()
  #*
  #*  Function description
  #*    This function returns the disassembly and the instruction size
  #*    of the instruction at "Addr"
  #*
  #*  Parameters
  #*    Addr    - Address of instruction to be disassembled
  #*
  #*  Return value
  #*    [0] InstSize:
  #*      >= 0 Instruction size
  #*       < 0 Error
  #*    [1] Disassembly string
  #*/
  def DisassembleInst(self, Addr):
    BufSize  = 64
    abDis    = bytes([0x00] * BufSize)
    InstSize = cdeclDLL.JLINKARM_DisassembleInst(abDis, BufSize, Addr)
    return InstSize, abDis.decode('utf-8').replace("\0", "")

  #/*********************************************************************
  #*
  #*       RTT
  #*
  #**********************************************************************
  #*/

  #/*********************************************************************
  #*
  #*       RTTERMINAL_Start()
  #*
  #*  Function description
  #*    Starts RTT processing. This includes background read of RTT
  #*    data from target. CntrlBlockAddress may be None.
  #*
  #*  Parameters
  #*    CntrlBlockAddress - RTT Control block address.
  #*                        If None / not passed => Autodetection
  #*  Return value
  #*      0 O.K.
  #*    < 0 Error
  #*/
  def RTTERMINAL_Start(self, CntrlBlockAddress = None):
    RTTStart = NULL
    if (CntrlBlockAddress != None):
      RTTStart = RTTERMINAL_START(CntrlBlockAddress)
    r = self.RTTERMINAL_Control(RTTERMINAL_CMD.START, RTTStart)
    return r[0]

  #/*********************************************************************
  #*
  #*       RTTERMINAL_Stop()
  #*
  #*  Function description
  #*    Stops RTT on the J-Link and host side.
  #*    InvalidateTargetCB may be None
  #*
  #*  Parameters
  #*    InvalidateTargetCB - If set, RTTCB will be invalidated on target.
  #*
  #*  Return value
  #*      0 O.K. RTT stopped (was running)
  #*      1 O.K  RTT stopped (was not running)
  #*    < 0 Error
  #*/
  def RTTERMINAL_Stop(self, InvalidateTargetCB = None):
    RTTStop = NULL
    if (InvalidateTargetCB != None):
      RTTStop = RTTERMINAL_STOP(InvalidateTargetCB)
    r = self.RTTERMINAL_Control(RTTERMINAL_CMD.STOP, RTTStop)
    return r[0]

  #/*********************************************************************
  #*
  #*       RTTERMINAL_GetNumBuf()
  #*
  #*  Function description
  #*    After starting RTT, get the current number of up or down buffers.
  #*
  #*  Parameters
  #*    Direction - Direction of the buffer. (0 = Up; 1 = Down)
  #*
  #*  Return value
  #*   >= 0 O.K. (NumBuffers)
  #*    < 0 Error
  #*     -2 RTT Control Block not found (yet).
  #*/
  def RTTERMINAL_GetNumBuf(self, Direction):
    r = self.RTTERMINAL_Control(RTTERMINAL_CMD.GETNUMBUF, Direction)
    return r[0]

  #/*********************************************************************
  #*
  #*       RTTERMINAL_GetDesc()
  #*
  #*  Function description
  #*    After starting RTT, get the size, name, and flags of a buffer.
  #*
  #*  Parameters
  #*    BufferIndex - Index of the buffer to get info about.
  #*    Direction   - Direction of the buffer. (0 = Up; 1 = Down)
  #*
  #*  Return value
  #*   [0] <Result>
  #*     >= 0 O.K.
  #*      < 0 Error
  #*       -2 RTT Control Block not found (yet).
  #*   [1] sName
  #*   [2] SizeOfBuffer
  #*   [3] Flags
  #*/
  def RTTERMINAL_GetDesc(self, BufferIndex, Direction):
    RTTDesc = RTTERMINAL_BUFDESC(BufferIndex, Direction)
    r = self.RTTERMINAL_Control(RTTERMINAL_CMD.GETDESC, RTTDesc)
    return r[0], r[1].sName, r[1].SizeOfBuffer, r[1].Flags

  #/*********************************************************************
  #*
  #*       RTTERMINAL_GetStat()
  #*
  #*  Function description
  #*    Get RTT status information
  #*
  #*  Return value
  #*   [0] <Result>
  #*     >= 0 O.K.
  #*      < 0 Error
  #*   [1] RTTERMINAL_STATUS
  #*/
  def RTTERMINAL_GetStat(self):
    Status = RTTERMINAL_STATUS()
    r = self.RTTERMINAL_Control(RTTERMINAL_CMD.GETSTAT, Status)
    return r[0], r[1]

  #/*********************************************************************
  #*
  #*       RTTERMINAL_Control()
  #*
  #*  Function description
  #*    This function calls an internal command to control RTT.
  #*
  #*  Parameters
  #*    Cmd           - Command to be executed
  #*    ControlStruct - Structure containing command parameters
  #*
  #*  Return value
  #*    <Result>, <ControlStruct>
  #*/
  def RTTERMINAL_Control(self, Cmd, p):
    #
    # Prepare parameters
    #
    if (p != None):
      if   (Cmd == RTTERMINAL_CMD.START):
        Obj = C_RTTERMINAL_START(p.ConfigBlockAddress)
      elif (Cmd == RTTERMINAL_CMD.STOP):
        Obj = C_RTTERMINAL_STOP(p.InvalidateTargetCB)
      elif (Cmd == RTTERMINAL_CMD.GETNUMBUF):
        Obj = c_uint32(p)
      elif (Cmd == RTTERMINAL_CMD.GETDESC):
        Obj = C_RTTERMINAL_BUFDESC(p.BufferIndex, p.Direction)
      elif (Cmd == RTTERMINAL_CMD.GETSTAT):
        Obj = C_RTTERMINAL_STATUS()
      else: # Type not defined? Raise error.
        raise JLinkError("RTT command unknown.")
      cp = byref(Obj)
    else:
      cp = NULL
    #
    # Handle function call and data
    #
    r = stdcallDLL.JLINK_RTTERMINAL_Control(Cmd, cp)
    if (Cmd == RTTERMINAL_CMD.GETDESC):
      p.sName               = Obj.acName.decode('utf-8')
      p.SizeOfBuffer        = Obj.SizeOfBuffer
      p.Flags               = Obj.Flags
    elif (Cmd == RTTERMINAL_CMD.GETSTAT):
      p.NumBytesTransferred = Obj.NumBytesTransferred
      p.NumBytesRead        = Obj.NumBytesRead
      p.HostOverflowCount   = Obj.HostOverflowCount
      p.IsRunning           = Obj.IsRunning
      p.NumUpBuffers        = Obj.NumUpBuffers
      p.NumDownBuffers      = Obj.NumDownBuffers
      p.OverflowMask        = Obj.OverflowMask
    return r, p

  #/*********************************************************************
  #*
  #*       RTTERMINAL_Read()
  #*
  #*  Function description
  #*    This function reads bytes from the RTT host-side buffer.
  #*
  #*  Parameters
  #*    BufferIndex - Index of the up buffer to read from.
  #*    NumBytes    - Max. number of bytes to read.
  #*
  #*  Return value
  #*    <NumBytesRead>
  #*      >= 0 NumBytesRead
  #*       < 0 Error
  #*    <abRead>
  #*      Read data (bytes)
  #*/
  def RTTERMINAL_Read(self, BufferIndex, NumBytes):
    abRead       = bytes([0xFF] * NumBytes)
    NumBytesRead = stdcallDLL.JLINK_RTTERMINAL_Read(BufferIndex, c_char_p(abRead), NumBytes)
    if (NumBytesRead < 0):  # Error occured? => throw Exception
      raise JLinkError("Failed to read RTT data from target.")
    return NumBytesRead, abRead

  #/*********************************************************************
  #*
  #*       RTTERMINAL_Write()
  #*
  #*  Function description
  #*    This function writes data into the RTT buffer.
  #*
  #*  Parameters
  #*    BufferIndex - Index of the down buffer to write to.
  #*    abWrite     - Data to write to target.
  #*    NumBytes    - Number of bytes to write.
  #*
  #*  Return value
  #*   >= 0 NumBytesWritten
  #*    < 0 Error
  #*/
  def RTTERMINAL_Write(self, BufferIndex, abWrite, NumBytes):
    abWrite  = bytes(abWrite)
    if (NumBytes == 0):
      NumBytes = len(abWrite)
    NumBytesWritten = stdcallDLL.JLINK_RTTERMINAL_Write(BufferIndex, c_char_p(abWrite), NumBytes)
    if (NumBytesWritten < 0):  # Error occured? => throw Exception
      raise JLinkError("Failed to write RTT data to target.")
    return NumBytesWritten

  #/*********************************************************************
  #*
  #*       STRACE
  #*
  #**********************************************************************
  #*/

  #/*********************************************************************
  #*
  #*       STRACE_GetInstStats()
  #*
  #*  Function description
  #*    Can be used to get execution information (fetch count, execution count, skip count) about
  #*    each instruction in your application from the moment JLINK_STRACE_Start() was called.
  #*    This function can be called while the system is running or when halted to get current sta-
  #*    tistics.
  #*
  #*  Parameters
  #*    Addr            - Adress of first instruction
  #*    NumItems        - Number of items to get stats from
  #*    Type            - Stat type.
  #*
  #*  Return value
  #*    [1]:
  #*      >= 0 Number of instruction addresses that could be "read" and have been stored to paItem.
  #*       < 0 Error
  #*    [2]:
  #*       Stats for "NumItems" depending on "Type"
  #*/
  def STRACE_GetInstStats(self, Addr, NumItems, Type):
    paItem       = None
    NumStructs   = 0
    aItem        = []
    #
    # We have to handle 4 different cases:
    # 1) NumStructs = NumItems
    # 2) NumStructs = 1
    # 3) NumStructs = (NumItems + 1) * 2
    # 4) NumStructs = (NumItems + 1) * 3
    #
    if   (Type == STRACE_CNT_TYPE.FETCHED or          # 1)
          Type == STRACE_CNT_TYPE.EXEC or
          Type == STRACE_CNT_TYPE.SKIP):
      NumStructs = NumItems
    elif (Type == STRACE_CNT_TYPE.TOTAL_FETCHED or    # 2)
          Type == STRACE_CNT_TYPE.TOTAL_EXEC or
          Type == STRACE_CNT_TYPE.TOTAL_SKIP or
          Type == STRACE_CNT_TYPE.TOTAL_NUM_INSTS):
      NumStructs = 1
    elif (Type == STRACE_CNT_TYPE.FETCHED_EXEC or     # 3)
          Type == STRACE_CNT_TYPE.FETCHED_SKIP or
          Type == STRACE_CNT_TYPE.EXEC_SKIP):
      NumStructs = (NumItems + 1) * 2
    elif (Type == STRACE_CNT_TYPE.FETCHED_EXEC_SKIP): # 4)
      NumStructs = (NumItems + 1) * 3
    #
    # Init pointer
    #
    try:
      paItem = (C_STRACE_INST_STAT * NumStructs)()
    except:
      raise JLinkError("Could not allocate memory: %d" %paItem)
    r = stdcallDLL.JLINK_STRACE_GetInstStats(paItem, c_uint32(Addr), c_uint32(NumStructs), c_uint32(8), c_uint32(Type))
    if (r < 0):
      raise JLinkError("STRACE_GetInstStats failed: %d" %r)
    #
    # Convert data
    #
    if   (Type == STRACE_CNT_TYPE.FETCHED or          # Multiple items of the same kind
          Type == STRACE_CNT_TYPE.EXEC or
          Type == STRACE_CNT_TYPE.SKIP):
      for Item in paItem:
        aItem.append(Item.ExecCnt)
      return aItem
    elif (Type == STRACE_CNT_TYPE.TOTAL_FETCHED or    # One item
          Type == STRACE_CNT_TYPE.TOTAL_EXEC or
          Type == STRACE_CNT_TYPE.TOTAL_SKIP or
          Type == STRACE_CNT_TYPE.TOTAL_NUM_INSTS):
      return paItem[0].ExecCnt
    else:                                             # Multiple items of different kinds
      FetchCnt = None
      ExecCnt  = None
      SkipCnt  = None
      for i in range(0, NumItems + 1):                # We use NumItems + 1 because of Total counts.
        if   (Type == STRACE_CNT_TYPE.FETCHED_EXEC):
          FetchCnt = paItem[i + 0].ExecCnt
          ExecCnt  = paItem[i + ((NumItems + 1) * 1)].ExecCnt
        elif (Type == STRACE_CNT_TYPE.FETCHED_SKIP):
          FetchCnt = paItem[i + 0].ExecCnt
          SkipCnt  = paItem[i + ((NumItems + 1) * 1)].ExecCnt
        elif (Type == STRACE_CNT_TYPE.EXEC_SKIP):
          ExecCnt = paItem[i + 0].ExecCnt
          SkipCnt = paItem[i + ((NumItems + 1) * 1)].ExecCnt
        elif (Type == STRACE_CNT_TYPE.FETCHED_EXEC_SKIP):
          FetchCnt = paItem[i + 0].ExecCnt
          ExecCnt  = paItem[i + ((NumItems + 1) * 1)].ExecCnt
          SkipCnt  = paItem[i + ((NumItems + 1) * 2)].ExecCnt
        Item = STRACE_INST_STAT(FetchCnt = FetchCnt, ExecCnt = ExecCnt, SkipCnt = SkipCnt)
        aItem.append(Item)
    return r, aItem

  #/*********************************************************************
  #*
  #*       STRACE_Start()
  #*
  #*  Function description
  #*    Starts capturing of STRACE data.
  #*
  #*  Return value
  #*   >= 0 O.K.
  #*    < 0 Error
  #*/
  def STRACE_Start(self):
    return stdcallDLL.JLINK_STRACE_Start()

  #/*********************************************************************
  #*
  #*       STRACE_Stop()
  #*
  #*  Function description
  #*    Stops sampling STRACE data. Optional capturing of STRACE data is automatically stopped
  #*    when the CPU is halted
  #*
  #*  Return value
  #*   >= 0 O.K.
  #*    < 0 Error
  #*/
  def STRACE_Stop(self):
    return stdcallDLL.JLINK_STRACE_Stop()

#/************************** end of file *****************************/
