#/*********************************************************************
#*               (c) SEGGER Microcontroller GmbH                      *
#*                        The Embedded Experts                        *
#*                           www.segger.com                           *
#**********************************************************************
#
#-------------------------- END-OF-HEADER -----------------------------
#
#Purpose: Implements all structs and struct classes for the jlinksdk package,
#         Similar to JLINKARM_Const.h for C
#Literature:
#  [1]  Python 3 Online Documentation https://docs.python.org/3/library/index.html
#  [2]  J-Link SDK Manual (UM08002)
#
#Additional information:
#  -
#*/

from ctypes import *   # Used to create C objects.

#/*********************************************************************
#*
#*       J-Link Errors related
#*
#**********************************************************************
#*/

#/*********************************************************************
#*
#*       JLINK_ERR
#*
#*  Global error codes.
#*  The error codes which are listed here can be returned by
#*  any DLL API-function which has a return value.
#*/
class JLINK_ERR:
  EMU_NO_CONNECTION            = -256  # (0xFFFFFF00) No connection to emulator / Connection to emulator lost
  EMU_COMM_ERROR               = -257  # (0xFFFFFEFF) Emulator communication error (host-interface module reproted error)
  DLL_NOT_OPEN                 = -258  # (0xFFFFFEFE) DLL has not been opened but needs to be (JLINKARM_Open() needs to be called first)
  VCC_FAILURE                  = -259  # (0xFFFFFEFD) Target system has no power (Measured VTref < 1V)
  INVALID_HANDLE               = -260  # (0xFFFFFEFC) File handle / memory area handle needed for operation, but given handle is not valid
  NO_CPU_FOUND                 = -261  # (0xFFFFFEFB) Could not find supported CPU
  EMU_FEATURE_NOT_SUPPORTED    = -262  # (0xFFFFFEFA) Emulator does not support the selected feature (Usually returned by functions which need specific emulator capabilities)
  EMU_NO_MEMORY                = -263  # (0xFFFFFEF9) Emulator does not have enough memory to perform the requested operation
  TIF_STATUS_ERROR             = -264  # (0xFFFFFEF8) Things such as "TCK is low but should be high"
  FLASH_PROG_COMPARE_FAILED    = -265
  FLASH_PROG_PROGRAM_FAILED    = -266
  FLASH_PROG_VERIFY_FAILED     = -267
  OPEN_FILE_FAILED             = -268
  UNKNOWN_FILE_FORMAT          = -269
  WRITE_TARGET_MEMORY_FAILED   = -270
  DEVICE_FEATURE_NOT_SUPPORTED = -271  # Connected device does not support specific feature
  WRONG_USER_CONFIG            = -272  # User configured DLL parameters incorrectly
  NO_TARGET_DEVICE_SELECTED    = -273  # User did not specify the core / device J-Link shall connect to
  CPU_IN_LOW_POWER_MODE        = -274

aTblErrorCodes = {
  JLINK_ERR.EMU_NO_CONNECTION            : "No connection to the emulator could be established.",
  JLINK_ERR.EMU_COMM_ERROR               : "A communication error between the emulator and the host occurred.",
  JLINK_ERR.DLL_NOT_OPEN                 : "JLINKARM_Open() needs to be called before using this function.",
  JLINK_ERR.VCC_FAILURE                  : "The target system has no power (Measured: VTref < 1V.",
  JLINK_ERR.INVALID_HANDLE               : "An invalid handle (e.g. file handle) was passed to the called function.",
  JLINK_ERR.NO_CPU_FOUND                 : "J-Link was unable to detect a supported core which is connected to J-Link.",
  JLINK_ERR.EMU_FEATURE_NOT_SUPPORTED    : "The emulator does not support the selected feature.",
  JLINK_ERR.EMU_NO_MEMORY                : "The emulator does not have enough memory to perform the requested operation.",
  JLINK_ERR.TIF_STATUS_ERROR             : "A target interface error occurred.",
  JLINK_ERR.FLASH_PROG_COMPARE_FAILED    : "Programmed data differs from source data.",
  JLINK_ERR.FLASH_PROG_PROGRAM_FAILED    : "Programming error occurred.",
  JLINK_ERR.FLASH_PROG_VERIFY_FAILED     : "Error while verifying programmed data.",
  JLINK_ERR.OPEN_FILE_FAILED             : "Specified file could not be opened.",
  JLINK_ERR.UNKNOWN_FILE_FORMAT          : "File format of selected file is not supported.",
  JLINK_ERR.WRITE_TARGET_MEMORY_FAILED   : "Could not write target memory.",
  JLINK_ERR.DEVICE_FEATURE_NOT_SUPPORTED : "The connected device does not support this feature.",
  JLINK_ERR.WRONG_USER_CONFIG            : "DLL parameters configured incorrectly by DLL.",
  JLINK_ERR.NO_TARGET_DEVICE_SELECTED    : "No target device selected.",
  JLINK_ERR.CPU_IN_LOW_POWER_MODE        : "CPU is in low power mode.",
}

class JLinkError(Exception):
  def __init__(self, value):
    if (value in aTblErrorCodes):     # Error code was passed?
      value = aTblErrorCodes[value]   # Use string from dict
    self.value = value
  def __str__(self):
    s = self.value
    return repr(s)

#/*********************************************************************
#*
#*       Public classes - Define/Enum like
#*
#**********************************************************************
#*/

#/*********************************************************************
#*
#*       RESET_TYPE
#*
#*  Class description
#*    This class is the python equivalent of the C enum "ARM_RESET_TYPE"
#*    from JLINKARM_Const.h
#*
#**********************************************************************
#*/
class RESET_TYPE:
  NORMAL = 0     # Resets core + peripherals. Reset pin is avoided where possible and reset via SFR access is preferred.
  #//
  #// --- Start ---
  #// Do NOT use anymore
  #//
  #JLINKARM_RESET_TYPE_BP0,
  #JLINKARM_RESET_TYPE_ADI,
  #JLINKARM_RESET_TYPE_NO_RESET,
  #JLINKARM_RESET_TYPE_HALT_WP,
  #JLINKARM_RESET_TYPE_HALT_DBGRQ,
  #JLINKARM_RESET_TYPE_SOFT,
  #JLINKARM_RESET_TYPE_HALT_DURING,
  #JLINKARM_RESET_TYPE_SAM7,
  #JLINKARM_RESET_TYPE_LPC,
  #//
  #// --- End ---
  #//
  #//
  #// Generic J-Link reset types (core independent)
  #// CPU-specific reset types are still in the header for backward compatibility but should not be used anymore
  #// All reset types halt the CPU before executing the first instruction of the user application, after reset release
  #// If the CPU incorporates a ROM bootloader, J-Link makes sure that this bootloader is executed and the CPU is halted as soon as it jumps into the user application code
  #//
  #// Note:
  #// If a specific reset type also resets the debug logic, it may happen that the CPU cannot be halted immediately after reset
  #// so it may have already executed some instructions before J-Link has a chance to halt it
  #//
  CORE      = 100  # Resets core only
  RESET_PIN = 101  # Toggles reset pin in order to issue a reset. Requires reset pin to be connected, otherwise result will be unpredictable
  #/*********************************************************************
  #*
  #*       Obsolete, only for compatibility with older versions
  #*                 Do not use anymore
  #*/
  #define JLINKARM_CM3_RESET_TYPE_NORMAL                  ((JLINKARM_RESET_TYPE)(0))      // Use RESET pin. If this fails, try to reset core.
  #define JLINKARM_CM3_RESET_TYPE_CORE                    ((JLINKARM_RESET_TYPE)(1))      // Resets the core only, not peripherals.
  #define JLINKARM_CM3_RESET_TYPE_RESETPIN                ((JLINKARM_RESET_TYPE)(2))      // Resets core & peripherals using RESET pin.
  #define JLINKARM_CM3_RESET_TYPE_CONNECT_UNDER_RESET     ((JLINKARM_RESET_TYPE)(3))      // Resets core & peripherals using RESET pin.
  #define JLINKARM_CM3_RESET_TYPE_HALT_AFTER_BTL          ((JLINKARM_RESET_TYPE)(4))      // Resets core & peripherals, halts the CPU after the bootloader
  #define JLINKARM_CM3_RESET_TYPE_HALT_BEFORE_BTL         ((JLINKARM_RESET_TYPE)(5))      // Resets core & peripherals, halts the CPU before the bootloader
  #define JLINKARM_CM3_RESET_TYPE_KINETIS                 ((JLINKARM_RESET_TYPE)(6))      //
  #define JLINKARM_CM3_RESET_TYPE_ADI_HALT_AFTER_KERNEL   ((JLINKARM_RESET_TYPE)(7))      //
  #define JLINKARM_CM3_RESET_TYPE_CORE_AND_PERIPHERALS    ((JLINKARM_RESET_TYPE)(8))      // Resets the core + peripherals
  #define JLINKARM_CM3_RESET_TYPE_LPC1200                 ((JLINKARM_RESET_TYPE)(9))
  #define JLINKARM_CM3_RESET_TYPE_S3FN60D                 ((JLINKARM_RESET_TYPE)(10))     // Performs a normal reset and disables the watchdog of the Samsung S3FN60D after the reset has been performed
  #define JLINKARM_CM3_RESET_TYPE_LPC11A                  ((JLINKARM_RESET_TYPE)(11))
  #define JLINKARM_CM3_RESET_TYPE_LPC176X                 ((JLINKARM_RESET_TYPE)(257))    // Used DLL-internally only. Automatically selected if LPC176x device is selected
  #define JLINK_PPC_RESET_TYPE_NORMAL                     ((JLINKARM_RESET_TYPE)(0))      // Resets core & peripherals using RESET pin.

#/*********************************************************************
#*
#*       SPEED
#*
#*  Class description
#*    This class is the python equivalent of the C defines "JLINKARM_SPEED_*"
#*    from JLINKARM_Const.h
#*
#**********************************************************************
#*/
class SPEED:
  ADAPTIVE      = 0xFFFF
  AUTO          = 0

#/*********************************************************************
#*
#*       HOST_IF
#*
#*  Class description
#*    This class is the python equivalent of the C defines "JLINKARM_HOSTIF_*"
#*    from JLINKARM_Const.h
#*
#**********************************************************************
#*/
class HOST_IF:
  USB           =    (1 << 0)
  TCPIP         =    (1 << 1)

#/*********************************************************************
#*
#*       TIF
#*
#*  Class description
#*    This class is the python equivalent of the C defines "JLINKARM_TIF_*"
#*    from JLINKARM_Const.h
#*
#**********************************************************************
#*/
class TIF:
  JTAG          =    0
  SWD           =    1
# BDM3          =    2   # Do NOT use. Not supported anymore. Only there for backward compatbility inside the DLL
  FINE          =    3
  ICSP          =    4   # Microchip 2-wire JTAG via TCK + TMS (e.g. PIC32)
  SPI           =    5
  C2            =    6
  CJTAG         =    7
  SWIM          =    8   # Only used Flasher PRO/ATE internally. J-Link does not support SWIM interface (yet)
  PDI           =    9   # Only used Flasher PRO/ATE internally. J-Link does not support PDI interface (yet)
  MC2WJTAG_TDI  =    10  # Microchip 2-wire JTAG via TCK + TDI (e.g. BT5511 8051 core)

#/*********************************************************************
#*
#*       ARM_REG
#*
#*  Class description
#*    This class is the python equivalent of the C enum "ARM_REG"
#*    from JLINKARM_Const.h
#*
#**********************************************************************
#*/
class ARM_REG:
  R0       = 0
  R1       = 1
  R2       = 2
  R3       = 3
  R4       = 4
  R5       = 5
  R6       = 6
  R7       = 7
  CPSR     = 8
  R15      = 9
  R8_USR   = 10
  R9_USR   = 11
  R10_USR  = 12
  R11_USR  = 13
  R12_USR  = 14
  R13_USR  = 15
  R14_USR  = 16
  SPSR_FIQ = 17
  R8_FIQ   = 18
  R9_FIQ   = 19
  R10_FIQ  = 20
  R11_FIQ  = 21
  R12_FIQ  = 22
  R13_FIQ  = 23
  R14_FIQ  = 24
  SPSR_SVC = 25
  R13_SVC  = 26
  R14_SVC  = 27
  SPSR_ABT = 28
  R13_ABT  = 29
  R14_ABT  = 30
  SPSR_IRQ = 31
  R13_IRQ  = 32
  R14_IRQ  = 33
  SPSR_UND = 34
  R13_UND  = 35
  R14_UND  = 36
  FPSID    = 37
  FPSCR    = 38
  FPEXC    = 39
  FPS0     = 40
  FPS1     = 41
  FPS2     = 42
  FPS3     = 43
  FPS4     = 44
  FPS5     = 45
  FPS6     = 46
  FPS7     = 47
  FPS8     = 48
  FPS9     = 49
  FPS10    = 50
  FPS11    = 51
  FPS12    = 52
  FPS13    = 53
  FPS14    = 54
  FPS15    = 55
  FPS16    = 56
  FPS17    = 57
  FPS18    = 58
  FPS19    = 59
  FPS20    = 60
  FPS21    = 61
  FPS22    = 62
  FPS23    = 63
  FPS24    = 64
  FPS25    = 65
  FPS26    = 66
  FPS27    = 67
  FPS28    = 68
  FPS29    = 69
  FPS30    = 70
  FPS31    = 71
  R8       = 72
  R9       = 73
  R10      = 74
  R11      = 75
  R12      = 76
  R13      = 77
  R14      = 78
  SPSR     = 79

#/*********************************************************************
#*
#*       CM3_REG
#*
#*  Class description
#*    This class is the python equivalent of the C enum "JLINKARM_CM3_REG"
#*    from JLINKARM_Const.h
#*
#**********************************************************************
#*/
class CM3_REG:
  R0                =  0  # HW-Reg
  R1                =  1  # HW-Reg
  R2                =  2  # HW-Reg
  R3                =  3  # HW-Reg
  R4                =  4  # HW-Reg
  R5                =  5  # HW-Reg
  R6                =  6  # HW-Reg
  R7                =  7  # HW-Reg
  R8                =  8  # HW-Reg
  R9                =  9  # HW-Reg
  R10               = 10  # HW-Reg
  R11               = 11  # HW-Reg
  R12               = 12  # HW-Reg
  R13               = 13  # Pseudo reg! It needs to be mapped to SP_MSP or SP_PSP, depending on current Controlregister:
  R14               = 14  # HW-Reg
  R15               = 15  # HW-Reg
  XPSR              = 16  # HW-Reg
  MSP               = 17  # HW-Reg  Main stack pointer
  PSP               = 18  # HW-Reg  Process stack pointer
  RAZ               = 19  # HW-Reg, Unused/Reserved
  CFBP              = 20  # HW-Reg, CONTROL/FAULTMASK/BASEPRI/PRIMASK (packed into 4 bytes of word. CONTROL = CFBP[31:24], FAULTMASK = CFBP[16:23], BASEPRI = CFBP[15:8], PRIMASK = CFBP[7:0]
  APSR              = 21  # Pseudo reg. (Part of XPSR)
  EPSR              = 22  # Pseudo reg. (Part of XPSR)
  IPSR              = 23  # Pseudo reg. (Part of XPSR)
  #
  # Data for CFBP pseudo regs is expected & returned
  # in same byte lane as when reading/writing the CFBP.
  # This means when reading
  #  PRIMASK,     the data of PRIMASK is expected/returned at     bits [7:0]
  #  BASEPRI,     the data of BASEPRI is expected/returned at     bits [15:8]
  #  BASEPRI_MAX, the data of BASEPRI_MAX is expected/returned at bits [15:8]
  #  FAULTMASK,   the data of FAULTMASK is expected/returned at   bits [23:16]
  #  CONTROL,     the data of CONTROL is expected/returned at     bits [31:24]
  #
  # Sample CFBP = 0xx11223344
  # Read PRIMASK   will return 0x00000044
  # Read BASEPRI   will return 0x00003300
  # Read FAULTMASK will return 0x00220000
  # Read CONTROL   will return 0x11000000
  # When writing, data is expected at the same position
  #
  # Note:
  # For BASEPRI, BASEPRI_MAX, FAULTMASK, CONTROL base 0 (always shifted to byte-lane starting at bit 0), please use:
  # BASEPRI_BASE0, BASEPRI_MAX_BASE0, FAULTMASK_BASE0, CONTROL_BASE0
  #
  #
  PRIMASK           = 24  # Pseudo reg. (Part of CFBP)
  BASEPRI           = 25  # Pseudo reg. (Part of CFBP)
  FAULTMASK         = 26  # Pseudo reg. (Part of CFBP)
  CONTROL           = 27  # Pseudo reg. (Part of CFBP)
  BASEPRI_MAX       = 28  # Pseudo reg. (Part of CFBP)
  IAPSR             = 29  # Pseudo reg. (Part of XPSR)
  EAPSR             = 30  # Pseudo reg. (Part of XPSR)
  IEPSR             = 31  # Pseudo reg. (Part of XPSR)
  #
  # Pseudo registers (not really CPU registers but handled as such ones
  #
  DWT_CYCCNT  = 65
  #
  # New regs introduced with ARMv8M architecture
  #
  MSP_NS      = 66
  PSP_NS      = 67
  MSP_S       = 68
  PSP_S       = 69
  MSPLIM_S    = 70
  PSPLIM_S    = 71
  MSPLIM_NS   = 72
  PSPLIM_NS   = 73
  CFBP_S      = 74
  CFBP_NS     = 75
  #
  # Data for CFBP pseudo regs is expected & returned
  # in same byte lane as when reading/writing the CFBP.
  # This means when reading
  #  PRIMASK,     the data of PRIMASK is expected/returned at     bits [7:0]
  #  BASEPRI,     the data of BASEPRI is expected/returned at     bits [15:8]
  #  BASEPRI_MAX, the data of BASEPRI_MAX is expected/returned at bits [15:8]
  #  FAULTMASK,   the data of FAULTMASK is expected/returned at   bits [23:16]
  #  CONTROL,     the data of CONTROL is expected/returned at     bits [31:24]
  #
  # Sample CFBP = 0xx11223344
  # Read PRIMASK   will return 0x00000044
  # Read BASEPRI   will return 0x00003300
  # Read FAULTMASK will return 0x00220000
  # Read CONTROL   will return 0x11000000
  # When writing, data is expected at the same position
  #
  PRIMASK_NS        = 76  # Pseudo reg. (Part of CFBP)
  BASEPRI_NS        = 77  # Pseudo reg. (Part of CFBP)
  FAULTMASK_NS      = 78  # Pseudo reg. (Part of CFBP)
  CONTROL_NS        = 79  # Pseudo reg. (Part of CFBP)
  BASEPRI_MAX_NS    = 80  # Pseudo reg. (Part of CFBP)
  PRIMASK_S         = 81  # Pseudo reg. (Part of CFBP)
  BASEPRI_S         = 82  # Pseudo reg. (Part of CFBP)
  FAULTMASK_S       = 83  # Pseudo reg. (Part of CFBP)
  CONTROL_S         = 84  # Pseudo reg. (Part of CFBP)
  BASEPRI_MAX_S     = 85  # Pseudo reg. (Part of CFBP)
  MSPLIM            = 86
  PSPLIM            = 87
  BASEPRI_BASE0     = 88  # (CFBP[15:8]  >>  8) & 0xFF
  FAULTMASK_BASE0   = 89  # (CFBP[23:16] >> 16) & 0xFF
  CONTROL_BASE0     = 90  # (CFBP[31:24] >> 24) & 0xFF
  BASEPRI_MAX_BASE0 = 91  # (CFBP[15:8]  >>  8) & 0xFF

#/*********************************************************************
#*
#*       CM4_REG
#*
#*  Class description
#*    This class is the python equivalent of the C enum "JLINKARM_CM4_REG"
#*    from JLINKARM_Const.h
#*
#**********************************************************************
#*/
class CM4_REG:
  R0                =  0
  R1                =  1
  R2                =  2
  R3                =  3
  R4                =  4
  R5                =  5
  R6                =  6
  R7                =  7
  R8                =  8
  R9                =  9
  R10               = 10
  R11               = 11
  R12               = 12
  R13               = 13  # Pseudo reg! It needs to be mapped to SP_MSP or SP_PSP, depending on current Controlregister:
  R14               = 14
  R15               = 15
  XPSR              = 16
  MSP               = 17
  PSP               = 18
  RAZ               = 19  # Reserved
  CFBP              = 20  # CONTROL/FAULTMASK/BASEPRI/PRIMASK (packed into 4 bytes of word. CONTROL = CFBP[31:24], FAULTMASK = CFBP[16:23], BASEPRI = CFBP[15:8], PRIMASK = CFBP[7:0]
  APSR              = 21  # Pseudo reg. (Part of XPSR)
  EPSR              = 22  # Pseudo reg. (Part of XPSR)
  IPSR              = 23  # Pseudo reg. (Part of XPSR)
  #
  # Data for CFBP pseudo regs is expected & returned
  # in same byte lane as when reading/writing the CFBP.
  # This means when reading
  #  PRIMASK,     the data of PRIMASK is expected/returned at     bits [7:0]
  #  BASEPRI,     the data of BASEPRI is expected/returned at     bits [15:8]
  #  BASEPRI_MAX, the data of BASEPRI_MAX is expected/returned at bits [15:8]
  #  FAULTMASK,   the data of FAULTMASK is expected/returned at   bits [23:16]
  #  CONTROL,     the data of CONTROL is expected/returned at     bits [31:24]
  #
  # Sample CFBP = 0xx11223344
  # Read PRIMASK   will return 0x00000044
  # Read BASEPRI   will return 0x00003300
  # Read FAULTMASK will return 0x00220000
  # Read CONTROL   will return 0x11000000
  # When writing, data is expected at the same position
  #
  PRIMASK           = 24  # Pseudo reg. (Part of CFBP)
  BASEPRI           = 25  # Pseudo reg. (Part of CFBP)
  FAULTMASK         = 26  # Pseudo reg. (Part of CFBP)
  CONTROL           = 27  # Pseudo reg. (Part of CFBP)
  BASEPRI_MAX       = 28  # Pseudo reg. (Part of CFBP)
  IAPSR             = 29  # Pseudo reg. (Part of XPSR)
  EAPSR             = 30  # Pseudo reg. (Part of XPSR)
  IEPSR             = 31  # Pseudo reg. (Part of XPSR)
  FPSCR             = 32
  FPS0              = 33
  FPS1              = 34
  FPS2              = 35
  FPS3              = 36
  FPS4              = 37
  FPS5              = 38
  FPS6              = 39
  FPS7              = 40
  FPS8              = 41
  FPS9              = 42
  FPS10             = 43
  FPS11             = 44
  FPS12             = 45
  FPS13             = 46
  FPS14             = 47
  FPS15             = 48
  FPS16             = 49
  FPS17             = 50
  FPS18             = 51
  FPS19             = 52
  FPS20             = 53
  FPS21             = 54
  FPS22             = 55
  FPS23             = 56
  FPS24             = 57
  FPS25             = 58
  FPS26             = 59
  FPS27             = 60
  FPS28             = 61
  FPS29             = 62
  FPS30             = 63
  FPS31             = 64
  #
  # Pseudo registers (not really CPU registers but handled as such ones
  #
  DWT_CYCCNT        = 65
  #
  # New regs introduced with ARMv8M architecture
  #
  MSP_NS      = 66
  PSP_NS      = 67
  MSP_S       = 68
  PSP_S       = 69
  MSPLIM_S    = 70
  PSPLIM_S    = 71
  MSPLIM_NS   = 72
  PSPLIM_NS   = 73
  CFBP_S      = 74
  CFBP_NS     = 75
  #
  # Data for CFBP pseudo regs is expected & returned
  # in same byte lane as when reading/writing the CFBP.
  # This means when reading
  #  PRIMASK,     the data of PRIMASK is expected/returned at     bits [7:0]
  #  BASEPRI,     the data of BASEPRI is expected/returned at     bits [15:8]
  #  BASEPRI_MAX, the data of BASEPRI_MAX is expected/returned at bits [15:8]
  #  FAULTMASK,   the data of FAULTMASK is expected/returned at   bits [23:16]
  #  CONTROL,     the data of CONTROL is expected/returned at     bits [31:24]
  #
  # Sample CFBP = 0xx11223344
  # Read PRIMASK   will return 0x00000044
  # Read BASEPRI   will return 0x00003300
  # Read FAULTMASK will return 0x00220000
  # Read CONTROL   will return 0x11000000
  # When writing, data is expected at the same position
  #
  PRIMASK_NS        = 75  # Pseudo reg. (Part of CFBP)
  BASEPRI_NS        = 76  # Pseudo reg. (Part of CFBP)
  FAULTMASK_NS      = 77  # Pseudo reg. (Part of CFBP)
  CONTROL_NS        = 78  # Pseudo reg. (Part of CFBP)
  BASEPRI_MAX_NS    = 79  # Pseudo reg. (Part of CFBP)
  PRIMASK_S         = 80  # Pseudo reg. (Part of CFBP)
  BASEPRI_S         = 81  # Pseudo reg. (Part of CFBP)
  FAULTMASK_S       = 82  # Pseudo reg. (Part of CFBP)
  CONTROL_S         = 83  # Pseudo reg. (Part of CFBP)
  BASEPRI_MAX_S     = 84  # Pseudo reg. (Part of CFBP)
  MSPLIM            = 85  # Either real or pseudo reg, depending on if security extensions are implemented or not
  PSPLIM            = 86  # Either real or pseudo reg, depending on if security extensions are implemented or not

#/*********************************************************************
#*
#*       CORTEX_R4_REG
#*
#*  Class description
#*    This class is the python equivalent of the C enum "JLINKARM_CORTEX_R4_REG"
#*    from JLINKARM_Const.h
#*
#**********************************************************************
#*/
class CORTEX_R4_REG:
  R0          =  0
  R1          =  1
  R2          =  2
  R3          =  3
  R4          =  4
  R5          =  5
  R6          =  6
  R7          =  7
  CPSR        =  8
  R15         =  9
  R8_USR      = 10
  R9_USR      = 11
  R10_USR     = 12
  R11_USR     = 13
  R12_USR     = 14
  R13_USR     = 15
  R14_USR     = 16
  SPSR_FIQ    = 17
  R8_FIQ      = 18
  R9_FIQ      = 19
  R10_FIQ     = 20
  R11_FIQ     = 21
  R12_FIQ     = 22
  R13_FIQ     = 23
  R14_FIQ     = 24
  SPSR_SVC    = 25
  R13_SVC     = 26
  R14_SVC     = 27
  SPSR_ABT    = 28
  R13_ABT     = 29
  R14_ABT     = 30
  SPSR_IRQ    = 31
  R13_IRQ     = 32
  R14_IRQ     = 33
  SPSR_UND    = 34
  R13_UND     = 35
  R14_UND     = 36
  FPSID       = 37
  FPSCR       = 38
  FPEXC       = 39
  FPS0        = 40
  FPS1        = 41
  FPS2        = 42
  FPS3        = 43
  FPS4        = 44
  FPS5        = 45
  FPS6        = 46
  FPS7        = 47
  FPS8        = 48
  FPS9        = 49
  FPS10       = 50
  FPS11       = 51
  FPS12       = 52
  FPS13       = 53
  FPS14       = 54
  FPS15       = 55
  FPS16       = 56
  FPS17       = 57
  FPS18       = 58
  FPS19       = 59
  FPS20       = 60
  FPS21       = 61
  FPS22       = 62
  FPS23       = 63
  FPS24       = 64
  FPS25       = 65
  FPS26       = 66
  FPS27       = 67
  FPS28       = 68
  FPS29       = 69
  FPS30       = 70
  FPS31       = 71
  MVFR0       = 72
  MVFR1       = 73
  R8          = 74
  R9          = 75
  R10         = 76
  R11         = 77
  R12         = 78
  R13         = 79
  R14         = 80
  SPSR        = 81   # (0x51)
  D16         = 82   # (0x52), 64-bit only. Only available on CPUs with implement VFP with D16-D31
  D17         = 83   # (0x53), 64-bit only. Only available on CPUs with implement VFP with D16-D31
  D18         = 84   # (0x54), 64-bit only. Only available on CPUs with implement VFP with D16-D31
  D19         = 85   # (0x55), 64-bit only. Only available on CPUs with implement VFP with D16-D31
  D20         = 86   # (0x56), 64-bit only. Only available on CPUs with implement VFP with D16-D31
  D21         = 87   # (0x57), 64-bit only. Only available on CPUs with implement VFP with D16-D31
  D22         = 88   # (0x58), 64-bit only. Only available on CPUs with implement VFP with D16-D31
  D23         = 89   # (0x59), 64-bit only. Only available on CPUs with implement VFP with D16-D31
  D24         = 90   # (0x5A), 64-bit only. Only available on CPUs with implement VFP with D16-D31
  D25         = 91   # (0x5B), 64-bit only. Only available on CPUs with implement VFP with D16-D31
  D26         = 92   # (0x5C), 64-bit only. Only available on CPUs with implement VFP with D16-D31
  D27         = 93   # (0x5D), 64-bit only. Only available on CPUs with implement VFP with D16-D31
  D28         = 94   # (0x5E), 64-bit only. Only available on CPUs with implement VFP with D16-D31
  D29         = 95   # (0x5F), 64-bit only. Only available on CPUs with implement VFP with D16-D31
  D30         = 96   # (0x60), 64-bit only. Only available on CPUs with implement VFP with D16-D31
  D31         = 97   # (0x61), 64-bit only. Only available on CPUs with implement VFP with D16-D31

#/*********************************************************************
#*
#*       RX_REG
#*
#*  Class description
#*    This class is the python equivalent of the C enum "JLINKARM_RX_REG"
#*    from JLINKARM_Const.h
#*
#**********************************************************************
#*/
class RX_REG:
  R0                 = 0
  R1                 = 1
  R2                 = 2
  R3                 = 3
  R4                 = 4
  R5                 = 5
  R6                 = 6
  R7                 = 7
  R8                 = 8
  R9                 = 9
  R10                = 10
  R11                = 11
  R12                = 12
  R13                = 13
  R14                = 14
  R15                = 15
  ISP                = 16
  USP                = 17
  INTB               = 18
  PC                 = 19
  PSW                = 20
  BPC                = 21
  BPSW               = 22
  FINTV              = 23
  FPSW               = 24
  CPEN               = 25
  ACCUH              = 26  # ACCU0[63:32]  (On RXv1 ACC[63:32] as there is only one ACC)
  ACCUL              = 27  # ACCU0[31:0]   (On RXv1 ACC[31:0] as there is only one ACC)
  ACCUE              = 28  # For RXv2: ACCU0[95:64], not present for RXv1
  ACCU1H             = 29  # For RXv2: ACCU1[63:32], not present for RXv1
  ACCU1L             = 30  # For RXv2: ACCU1[31:0], not present for RXv1
  ACCU1E             = 31  # For RXv2: ACCU1[95:64], not present for RXv1
  EXTB               = 32

#/*********************************************************************
#*
#*       MIPS_REG
#*
#*  Class description
#*    This class is the python equivalent of the C enum "JLINK_MIPS_REG"
#*    from JLINKARM_Const.h
#*
#**********************************************************************
#*/
class MIPS_REG:
  #
  #  General purpose registers:
  #
  R0            = 0   # r0 (zero)      Always 0 (hard-wired)
  R1            = 1   # r1 (at)        Assembler Temporary
  R2            = 2   # r2 (v0)        Function Return Values
  R3            = 3   # r3 (v1)        Function Return Values
  R4            = 4   # r4 (a0)        Function Arguments
  R5            = 5   # r5 (a1)        Function Arguments
  R6            = 6   # r6 (a2)        Function Arguments
  R7            = 7   # r7 (a3)        Function Arguments
  R8            = 8   # r8 (t0)        Temporary - Caller does not need to preserve contents
  R9            = 9   # r9 (t1)        Temporary - Caller does not need to preserve contents
  R10           = 10  # r10 (t2)       Temporary - Caller does not need to preserve contents
  R11           = 11  # r11 (t3)       Temporary - Caller does not need to preserve contents
  R12           = 12  # r12 (t4)       Temporary - Caller does not need to preserve contents
  R13           = 13  # r13 (t5)       Temporary - Caller does not need to preserve contents
  R14           = 14  # r14 (t6)       Temporary - Caller does not need to preserve contents
  R15           = 15  # r15 (t7)       Temporary - Caller does not need to preserve contents
  R16           = 16  # r16 (s0)       Saved Temporary - Caller must preserve contents
  R17           = 17  # r17 (s1)       Saved Temporary - Caller must preserve contents
  R18           = 18  # r18 (s2)       Saved Temporary - Caller must preserve contents
  R19           = 19  # r19 (s3)       Saved Temporary - Caller must preserve contents
  R20           = 20  # r20 (s4)       Saved Temporary - Caller must preserve contents
  R21           = 21  # r21 (s5)       Saved Temporary - Caller must preserve contents
  R22           = 22  # r22 (s6)       Saved Temporary - Caller must preserve contents
  R23           = 23  # r23 (s7)       Saved Temporary - Caller must preserve contents
  R24           = 24  # r24 (t8)       Temporary - Caller does not need to preserve contents
  R25           = 25  # r25 (t9)       Temporary - Caller does not need to preserve contents
  R26           = 26  # r26 (k0)       Kernel temporary - Used for interrupt and exception handling
  R27           = 27  # r27 (k1)       Kernel temporary - Used for interrupt and exception handling
  R28           = 28  # r28 (gp)       Global Pointer - Used for fast-access common data
  R29           = 29  # r29 (sp)       Stack Pointer - Software stack
  R30           = 30  # r30 (s8 or fp) Saved Temporary - Caller must preserve contents OR Frame Pointer - Pointer to procedure frame on stack
  R31           = 31  # r31 (ra)       Return Address (hard-wired)
  #
  # CP0 registers
  #
  HWRENA        = 32  # HWREna        (CP0R7,  Sel0)
  BADVADDR      = 33  # BadVAddr      (CP0R8,  Sel0)
  COUNT         = 34  # Count         (CP0R9,  Sel0)
  COMPARE       = 35  # Compare       (CP0R11, Sel0)
  STATUS        = 36  # Status        (CP0R12, Sel0)
  INTCTL        = 37  # IntCtl        (CP0R12, Sel1)
  SRSCTL        = 38  # SRSCtl        (CP0R12, Sel2)
  SRSMAP        = 39  # SRSMap        (CP0R12, Sel3)
  CAUSE         = 40  # Cause         (CP0R13, Sel0)
  EPC           = 41  # EPC           (CP0R14, Sel0)
  PRID          = 42  # PRId          (CP0R15, Sel0)
  EBASE         = 43  # EBASE         (CP0R15, Sel1)
  CONFIG        = 44  # Config        (CP0R16, Sel0)
  CONFIG1       = 45  # Config1       (CP0R16, Sel1)
  CONFIG2       = 46  # Config2       (CP0R16, Sel2)
  CONFIG3       = 47  # Config3       (CP0R16, Sel3)
  DEBUG         = 48  # Debug         (CP0R23, Sel0)
  TRACECONTROL  = 49  # TraceControl  (CP0R23, Sel1)
  TRACECONTROL2 = 50  # TraceControl2 (CP0R23, Sel2)
  USERTRACEDATA = 51  # UserTraceData (CP0R23, Sel3)
  TRACEBPC      = 52  # TraceBPC      (CP0R23, Sel4)
  DEBUG2        = 53  # Debug2        (CP0R23, Sel5) CP0R23, Sel 6 on microAptiv core
  PC            = 54  # DEPC          (CP0R24, Sel0)
  ERROR_PC      = 55  # ErrorEPC      (CP0R30, Sel0)
  DESAVE        = 56  # DESAVE        (CP0R31, Sel0)
  #
  # Special purpose registers
  #
  HI            = 57  # HI
  LO            = 58  # LO
  #
  # Additional registers (available on microAptiv core only)
  #
  LO1              = 59
  LO2              = 60
  LO3              = 61
  HI1              = 62
  HI2              = 63
  HI3              = 64
  INDEX            = 65   # Index                 (CP0R0, Sel0)                 Index into the TLB array (microAptiv MPU only).
  RANDOM           = 66   # Random                (CP0R1, Sel0)                 Randomly generated index into the TLB array (microAptiv MPU only).
  ENTRY_LO0        = 67   # EntryLo0              (CP0R2, Sel0)                 Low-order portion of the TLB entry for even-numbered virtual pages (microAptiv MPU only).
  ENTRY_LO1        = 68   # EntryLo1              (CP0R3, Sel0)                 Low-order portion of the TLB entry for odd-numbered virtual pages (microAptiv MPU only).
  CONTEXT          = 69   # Context               (CP0R4, Sel0)                 Pointer to the page table entry in memory (microAptiv MPU only).
  USER_LOCAL       = 70   # UserLocal             (CP0R4, Sel2)                 User information that can be written by privileged software and read via the RDHWR instruction.
  PAGE_MASK        = 71   # PageMask              (CP0R5, Sel0)                 PageMask controls the variable page sizes in TLB entries.
  PAGE_GRAIN       = 72   # PageGrain             (CP0R5, Sel1)                 PageGrain enables support of 1 KB pages in the TLB (microAptiv MPU only).
  WIRED            = 73   # Wired                 (CP0R6, Sel0)                 Controls the number of fixed (i.e., wired) TLB entries (microAptiv MPU only).
  BADINSTR         = 74   # BadInstr              (CP0R8, Sel1)                 Reports the instruction that caused the most recent exception
  BADINSTRP        = 75   # BadInstrP             (CP0R8, Sel2)                 Reports the branch instruction if a delay slot caused the most recent exception
  ENTRYHI          = 76   # EntryHi               (CP0R10, Sel0)                High-order portion of the TLB entry (microAptiv MPU only).
  VIEWIPL          = 77   # View_IPL              (CP0R12, Sel4)                Allows the Priority Level to be read/written without extracting or inserting that bit from/to the Status register.
  SRSMAP2          = 78   # SRSMAP2               (CP0R12, Sel5)                Contains two 4-bit fields that provide the mapping from a vector number to the shadow set number to use when servicing such an interrupt.
  VIEW_RIPL        = 79   # View_RIPL             (CP0R13, Sel4)                Enables read access to the RIPL bit that is available in the Cause register.
  NESTEDEXC        = 80   # NestedExc             (CP0R13, Sel5)                Contains the error and exception level status bit values that existed prior to the current exception.
  NESTEDEPC        = 81   # NestedEPC             (CP0R14, Sel2)                Contains the exception program counter that existed prior to the current exception.
  CDMMBASE         = 82   # CDMMBase              (CP0R15, Sel2)                Common device memory map base.
  CONFIG4          = 83   # Config4               (CP0R16, Sel4)                Configuration register 4.
  CONFIG5          = 84   # Config5               (CP0R16, Sel5)                Configuration register 5.
  CONFIG7          = 85   # Config7               (CP0R16, Sel7)                Configuration register 7.
  LLADDR           = 86   # LLAddr                (CP0R17, Sel0)                Load link address (microAptiv MPU only).
  USERTRACEDATA2   = 87   # UserTraceData2        (CP0R24, Sel3)                EJTAG user trace data 2 register.
  PERFCTL0         = 88   # PerfCtl0              (CP0R25, Sel0)                Performance counter 0 control.
  PERFCNT0         = 89   # PerfCnt0              (CP0R25, Sel1)                Performance counter 0.
  PERFCTL1         = 90   # PerfCtl1              (CP0R25, Sel2)                Performance counter 1 control.
  PERFCNT1         = 91   # PerfCnt1              (CP0R25, Sel3)                Performance counter 1.
  ERRCTL           = 92   # ErrCtl                (CP0R26, Sel0)                Software test enable of way-select and data RAM arrays for I-Cache and D-Cache (microAptiv MPU only).
  CACHEERR         = 93   # CacheErr              (CP0R27, Sel0)                Records of information about cache/SPRAM parity errors
  TAGLO            = 94   # TagLo                 (CP0R28, Sel0)                Low-order portion of cache tag interface (microAptiv MPU only).
  DATALO           = 95   # DataLo                (CP0R28, Sel1)                Low-order portion of cache tag interface (microAptiv MPU only).
  KSCRATCH1        = 96   # KScratch1             (CP0R31, Sel2)                Scratch Register for Kernel Mode
  KSCRATCH2        = 97   # KScratch2             (CP0R31, Sel3)                Scratch Register for Kernel Mode
  WATCHLO0         = 98   # WatchLo0              (CP0R18, Sel0)                Low-order watchpoint address (microAptiv MPU only).
  WATCHLO1         = 99   # WatchLo1              (CP0R18, Sel1)                Low-order watchpoint address (microAptiv MPU only).
  WATCHLO2         = 100  # WatchLo2              (CP0R18, Sel2)                Low-order watchpoint address (microAptiv MPU only).
  WATCHLO3         = 101  # WatchLo3              (CP0R18, Sel3)                Low-order watchpoint address (microAptiv MPU only).
  WATCHLO4         = 102  # WatchLo4              (CP0R18, Sel4)                Low-order watchpoint address (microAptiv MPU only).
  WATCHLO5         = 103  # WatchLo5              (CP0R18, Sel5)                Low-order watchpoint address (microAptiv MPU only).
  WATCHLO6         = 104  # WatchLo6              (CP0R18, Sel6)                Low-order watchpoint address (microAptiv MPU only).
  WATCHLO7         = 105  # WatchLo7              (CP0R18, Sel7)                Low-order watchpoint address (microAptiv MPU only).
  WATCHHI0         = 106  # WatchHi0              (CP0R19, Sel0)                High-order watchpoint address (microAptiv MPU only).
  WATCHHI1         = 107  # WatchHi1              (CP0R19, Sel1)                High-order watchpoint address (microAptiv MPU only).
  WATCHHI2         = 108  # WatchHi2              (CP0R19, Sel2)                High-order watchpoint address (microAptiv MPU only).
  WATCHHI3         = 109  # WatchHi3              (CP0R19, Sel3)                High-order watchpoint address (microAptiv MPU only).
  WATCHHI4         = 110  # WatchHi4              (CP0R19, Sel4)                High-order watchpoint address (microAptiv MPU only).
  WATCHHI5         = 111  # WatchHi5             (CP0R19, Sel5)                High-order watchpoint address (microAptiv MPU only).
  WATCHHI6         = 112  # WatchHi6             (CP0R19, Sel6)                High-order watchpoint address (microAptiv MPU only).
  WATCHHI7         = 113  # WatchHi7             (CP0R19, Sel7)                High-order watchpoint address (microAptiv MPU only).

#/*********************************************************************
#*
#*       JLINK_8051_REG
#*
#*  Class description
#*    This class is the python equivalent of the C defines "JLINK_8051_REG_*"
#*    from JLINKARM_Const.h
#*
#**********************************************************************
#*/
class JLINK_8051_REG:
  #
  # Do NEVER change the numeric value of the register description, as certain parts of the DLL rely on this
  #
  R0_B0  = 0
  R1_B0  = 1
  R2_B0  = 2
  R3_B0  = 3
  R4_B0  = 4
  R5_B0  = 5
  R6_B0  = 6
  R7_B0  = 7
  R0_B1  = 8
  R1_B1  = 9
  R2_B1  = 10
  R3_B1  = 11
  R4_B1  = 12
  R5_B1  = 13
  R6_B1  = 14
  R7_B1  = 15
  R0_B2  = 16
  R1_B2  = 17
  R2_B2  = 18
  R3_B2  = 19
  R4_B2  = 20
  R5_B2  = 21
  R6_B2  = 22
  R7_B2  = 23
  R0_B3  = 24
  R1_B3  = 25
  R2_B3  = 26
  R3_B3  = 27
  R4_B3  = 28
  R5_B3  = 29
  R6_B3  = 30
  R7_B3  = 31
  PC     = 32
  A      = 33     # Accumulator
  B      = 34
  DPTR   = 35     # Data pointer
  SP     = 36     # Stack pointer
  PSW    = 37     # Processor status word
  R0     = 38     # Pseudo register. Mapped to R0_B0/1/2/3 depending on active bank select in PSW
  R1     = 39     # Pseudo register. Mapped to R1_B0/1/2/3 depending on active bank select in PSW
  R2     = 40     # Pseudo register. Mapped to R2_B0/1/2/3 depending on active bank select in PSW
  R3     = 41     # Pseudo register. Mapped to R3_B0/1/2/3 depending on active bank select in PSW
  R4     = 42     # Pseudo register. Mapped to R4_B0/1/2/3 depending on active bank select in PSW
  R5     = 43     # Pseudo register. Mapped to R5_B0/1/2/3 depending on active bank select in PSW
  R6     = 44     # Pseudo register. Mapped to R6_B0/1/2/3 depending on active bank select in PSW
  R7     = 45     # Pseudo register. Mapped to R7_B0/1/2/3 depending on active bank select in PSW

#/*********************************************************************
#*
#*       BT5511_REG
#*
#*  Class description
#*    This class is the python equivalent of the C defines "JLINK_BT5511_REG_*"
#*    from JLINKARM_Const.h
#*
#**********************************************************************
#*/
class BT5511_REG:
  #
  # BT5511 specific registers (start at index 47)
  #
  DPS    = 46   # 8-bit, DPTR sel register. Selects either DPTR or DPTR1
  DPTR1  = 47   # Data pointer register 1 (24-bit)
  DPL    = 48   # DPTR[7:0]
  DPH    = 49   # DPTR[15:8]
  DPX    = 50   # DPTR[23:16]
  DPL1   = 51   # DPTR1[7:0]
  DPH1   = 52   # DPTR1[15:8]
  DPX1   = 53   # DPTR1[23:16]
  ACON   = 54   # ACON SFR

#/*********************************************************************
#*
#*       CF_REG
#*
#*  Class description
#*    This class is the python equivalent of the C enum "JLINK_CF_REG"
#*    from JLINKARM_Const.h
#*
#**********************************************************************
#*/
class CF_REG:
  #
  # CPU registers
  #
  D0           = 0
  D1           = 1
  D2           = 2
  D3           = 3
  D4           = 4
  D5           = 5
  D6           = 6
  D7           = 7
  A0           = 8
  A1           = 9
  A2           = 10
  A3           = 11
  A4           = 12
  A5           = 13
  A6           = 14
  A7           = 15
  OTHER_A7     = 16
  USP          = 17        # User Stack Pointer
  SSP          = 18        # Supervisor Stack Pointer
  SR           = 19        # Status Register
  PC           = 20        # Program Counter
  PC_CORRECTED = 21        # Program Counter Corrected
  #
  # Misc. CPU registers
  #
  VBR          = 22          # Vector Base Register
  CACR         = 23          # Cache Control Register
  ACR0         = 24          # Access Control Register 0
  ACR1         = 25          # Access Control Register 1
  ACR2         = 26          # Access Control Register 2
  ACR3         = 27          # Access Control Register 3
  #
  #  MMU registers (only available if MMU is present)
  #
  ASID         = 28          # Address Space Identifier
  MMUBAR       = 29          # MMU Base Address Register
  #
  # MAC registers (only available if MAC is present)
  #
  MACSR        = 30          # MAC Status Register
  MASK         = 31          # MAC Address Mask Register
  ACC0         = 32          # MAC Accumulator 0
  #
  # EMAC registers (only available if EMAC is present)
  #
  ACC1         = 33          # MAC Accumulator 1
  ACC2         = 34          # MAC Accumulator 2
  ACC3         = 35          # MAC Accumulator 3
  ACCext01     = 36          # MAC Accumulator 0,1 extension bytes
  ACCext23     = 37          # MAC Accumulator 2,3 extension bytes
  #
  # FPU registers (only available if FPU is present)
  #
  FPU0         = 38          # FPU Data Register 0 (MSB)
  FPL0         = 39          # FPU Data Register 0 (LSB)
  FPU1         = 48          # FPU Data Register 1 (MSB)
  FPL1         = 41          # FPU Data Register 1 (LSB)
  FPU2         = 42          # FPU Data Register 2 (MSB)
  FPL2         = 43          # FPU Data Register 2 (LSB)
  FPU3         = 44          # FPU Data Register 3 (MSB)
  FPL3         = 45          # FPU Data Register 3 (LSB)
  FPU4         = 46          # FPU Data Register 4 (MSB)
  FPL4         = 47          # FPU Data Register 4 (LSB)
  FPU5         = 48          # FPU Data Register 5 (MSB)
  FPL5         = 49          # FPU Data Register 5 (LSB)
  FPU6         = 50          # FPU Data Register 6 (MSB)
  FPL6         = 51          # FPU Data Register 6 (LSB)
  FPU7         = 52          # FPU Data Register 7 (MSB)
  FPL7         = 53          # FPU Data Register 7 (LSB)
  FPIAR        = 54          # FPU Instruction Address Register
  FPSR         = 55          # FPU Status Register
  FPCR         = 56          # FPU Control Register

#/*********************************************************************
#*
#*       POWER_PC_REG
#*
#*  Class description
#*    This class is the python equivalent of the C enum "JLINK_POWER_PC_REG"
#*    from JLINKARM_Const.h
#*
#**********************************************************************
#*/
class POWER_PC_REG:
  #
  # General Purpose Registers
  #
  R0              = 0
  R1              = 1
  R2              = 2
  R3              = 3
  R4              = 4
  R5              = 5
  R6              = 6
  R7              = 7
  R8              = 8
  R9              = 9
  R10             = 10
  R11             = 11
  R12             = 12
  R13             = 13
  R14             = 14
  R15             = 15
  R16             = 16
  R17             = 17
  R18             = 18
  R19             = 19
  R20             = 20
  R21             = 21
  R22             = 22
  R23             = 23
  R24             = 24
  R25             = 25
  R26             = 26
  R27             = 27
  R28             = 28
  R29             = 29
  R30             = 30
  R31             = 31
  CR              = 32  # Condition Register
  CTR             = 33  # Count Register
  LR              = 34  # Link
  XER             = 35  # XER
  PC              = 36
  #
  # Processor Control Registers
  #
  MSR             = 37  # Machine State
  PVR             = 38  # Processor Version
  PIR             = 39  # Processor ID
  SVR             = 40  # System Version
  HID0            = 41  # Hardware Implementation Dependent
  HID1            = 42  # Hardware Implementation Dependent
  #
  # Exception Handling/Control Registers
  #
  SPRG0           = 43  # SPR General 0
  SPRG1           = 44  # SPR General 1
  SRR0            = 45  # Save and Restore
  SRR1            = 46  # Save and Restore
  CSRR0           = 47  # Save and Restore
  CSRR1           = 48  # Save and Restore
  DSRR0           = 49  # Save and Restore
  DSRR1           = 50  # Save and Restore
  ESR             = 51  # Exception Syndrome
  MCSR            = 52  # Machine Check Syndrome Register
  DEAR            = 53  # Data Exception Address
  IVPR            = 54  # Interrupt Vector Prefix
  #
  # Memory Management Registers
  #
  PID0            = 55  # Process ID
  MMUCFG          = 56
  #
  # Cache Registers
  #
  L1CFG0          = 57
  #
  # BTB Registers
  #
  BUCSR           = 58
  #
  # Debug Registers
  #
  DBCR0           = 59
  DBCR1           = 60
  DBCR2           = 61
  DBSR            = 62
  IAC1            = 63
  IAC2            = 64
  IAC3            = 65
  IAC4            = 66
  DAC1            = 67
  DAC2            = 68

#/*********************************************************************
#*
#*       RISCV_REG
#*
#*  Class description
#*    This class is the python equivalent of the C enum "JLINK_RISCV_REG"
#*    from JLINKARM_Const.h
#*
#**********************************************************************
#*/
class RISCV_REG:
  FFLAGS       = 0x001         # Bits [4:0] of FCSR
  FRM          = 0x002         # Bits [7:5] of FCSR
  FCSR         = 0x003         # Always 32-bit
  USTATUS      = 0x000         # 32/64-bit. Depends on RV32/64
  UIE          = 0x004         # 32/64-bit. Depends on RV32/64
  UTVEC        = 0x005         # Length = ???
  USCRATCH     = 0x040         # Length = ???
  UEPC         = 0x041         # 32/64-bit. Depends on RV32/64
  UCAUSE       = 0x042         # Length = ???
  UTVAL        = 0x043         # Length = ???
  UIP          = 0x044         # 32/64-bit. Depends on RV32/64
  #
  # Gap
  #
  SSTATUS     = 0x100          # 32/64-bit. Depends on RV32/64
  #
  # Gap
  #
  SEDELEG     = 0x102     # 32/64-bit. Depends on RV32/64
  SIDELEG     = 0x103     # 32/64-bit. Depends on RV32/64
  SIE         = 0x104     # 32/64-bit. Depends on RV32/64
  STVEC       = 0x105     # 32/64-bit. Depends on RV32/64
  SCOUNTEREN  = 0x106     # Always 32-bit
  #
  # Gap
  #
  SSCRATCH   = 0x140      # 32/64-bit. Depends on RV32/64
  SEPC       = 0x141      # 32/64-bit. Depends on RV32/64
  SCAUSE     = 0x142      # 32/64-bit. Depends on RV32/64
  STVAL      = 0x143      # 32/64-bit. Depends on RV32/64 Also called "SBADADDR" in some older manuals.
  SIP        = 0x144      # 32/64-bit. Depends on RV32/64
  #
  # Gap
  #
  SATP       = 0x0180     # 32/64-bit. Depends on RV32/64 Also called "SPTBR" in some older manuals.
  #
  # Gap
  #
  MSTATUS    = 0x300      # 32/64-bit. Depends on RV32/64
  MISA       = 0x301      # 32/64-bit. Depends on RV32/64
  MEDELEG    = 0x302      # 32/64-bit. Depends on RV32/64
  MIDELEG    = 0x303      # 32/64-bit. Depends on RV32/64
  MIE        = 0x304      # 32/64-bit. Depends on RV32/64
  MTVEC      = 0x305      # 32/64-bit. Depends on RV32/64
  MCOUNTEREN = 0x306      # Always 32-bit
  #
  # Gap
  #
  MHPMEVENT3  = 0x323     # 32/64-bit. Depends on RV32/64
  MHPMEVENT4  = 0x324     # 32/64-bit. Depends on RV32/64
  MHPMEVENT5  = 0x325     # 32/64-bit. Depends on RV32/64
  MHPMEVENT6  = 0x326     # 32/64-bit. Depends on RV32/64
  MHPMEVENT7  = 0x327     # 32/64-bit. Depends on RV32/64
  MHPMEVENT8  = 0x328     # 32/64-bit. Depends on RV32/64
  MHPMEVENT9  = 0x329     # 32/64-bit. Depends on RV32/64
  MHPMEVENT10 = 0x32A     # 32/64-bit. Depends on RV32/64
  MHPMEVENT11 = 0x32B     # 32/64-bit. Depends on RV32/64
  MHPMEVENT12 = 0x32C     # 32/64-bit. Depends on RV32/64
  MHPMEVENT13 = 0x32D     # 32/64-bit. Depends on RV32/64
  MHPMEVENT14 = 0x32E     # 32/64-bit. Depends on RV32/64
  MHPMEVENT15 = 0x32F     # 32/64-bit. Depends on RV32/64
  MHPMEVENT16 = 0x330     # 32/64-bit. Depends on RV32/64
  MHPMEVENT17 = 0x331     # 32/64-bit. Depends on RV32/64
  MHPMEVENT18 = 0x332     # 32/64-bit. Depends on RV32/64
  MHPMEVENT19 = 0x333     # 32/64-bit. Depends on RV32/64
  MHPMEVENT20 = 0x334     # 32/64-bit. Depends on RV32/64
  MHPMEVENT21 = 0x335     # 32/64-bit. Depends on RV32/64
  MHPMEVENT22 = 0x336     # 32/64-bit. Depends on RV32/64
  MHPMEVENT23 = 0x337     # 32/64-bit. Depends on RV32/64
  MHPMEVENT24 = 0x338     # 32/64-bit. Depends on RV32/64
  MHPMEVENT25 = 0x339     # 32/64-bit. Depends on RV32/64
  MHPMEVENT26 = 0x33A     # 32/64-bit. Depends on RV32/64
  MHPMEVENT27 = 0x33B     # 32/64-bit. Depends on RV32/64
  MHPMEVENT28 = 0x33C     # 32/64-bit. Depends on RV32/64
  MHPMEVENT29 = 0x33D     # 32/64-bit. Depends on RV32/64
  MHPMEVENT30 = 0x33E     # 32/64-bit. Depends on RV32/64
  MHPMEVENT31 = 0x33F     # 32/64-bit. Depends on RV32/64
  #
  # Gap
  #
  MSCRATCH   = 0x340       # 32/64-bit. Depends on RV32/64
  MEPC       = 0x341       # 32/64-bit. Depends on RV32/64
  MCAUSE     = 0x342       # 32/64-bit. Depends on RV32/64
  MTVAL      = 0x343       # Also called "MBADADDR" in some older manuals.
  MIP        = 0x344       # 32/64-bit. Depends on RV32/64
  #
  # Gap
  #
  PMPCFG0  = 0x3A0         # Always 32-bit
  PMPCFG1  = 0x3A1         # Always 32-bit
  PMPCFG2  = 0x3A2         # Always 32-bit
  PMPCFG3  = 0x3A3         # Always 32-bit
  #
  # Gap
  #
  PMPADDR0  = 0x3B0        # 32/64-bit. Depends on RV32/64
  PMPADDR1  = 0x3B1        # 32/64-bit. Depends on RV32/64
  PMPADDR2  = 0x3B2        # 32/64-bit. Depends on RV32/64
  PMPADDR3  = 0x3B3        # 32/64-bit. Depends on RV32/64
  PMPADDR4  = 0x3B4        # 32/64-bit. Depends on RV32/64
  PMPADDR5  = 0x3B5        # 32/64-bit. Depends on RV32/64
  PMPADDR6  = 0x3B6        # 32/64-bit. Depends on RV32/64
  PMPADDR7  = 0x3B7        # 32/64-bit. Depends on RV32/64
  PMPADDR8  = 0x3B8        # 32/64-bit. Depends on RV32/64
  PMPADDR9  = 0x3B9        # 32/64-bit. Depends on RV32/64
  PMPADDR10 = 0x3BA        # 32/64-bit. Depends on RV32/64
  PMPADDR11 = 0x3BB        # 32/64-bit. Depends on RV32/64
  PMPADDR12 = 0x3BC        # 32/64-bit. Depends on RV32/64
  PMPADDR13 = 0x3BD        # 32/64-bit. Depends on RV32/64
  PMPADDR14 = 0x3BE        # 32/64-bit. Depends on RV32/64
  PMPADDR15 = 0x3BF        # 32/64-bit. Depends on RV32/64
  #
  # Gap
  #
  TSELECT = 0x7A0          # 32/64-bit. Depends on RV32/64
  TDATA1  = 0x7A1          # 32/64-bit. Depends on RV32/64
  TDATA2  = 0x7A2          # 32/64-bit. Depends on RV32/64
  TDATA3  = 0x7A3          # 32/64-bit. Depends on RV32/64
  #
  # Gap
  #
  DCSR     = 0x7B0         # Always 32-bit
  DPC      = 0x7B1         # 32/64-bit. Depends on RV32/64
  DSCRATCH = 0x7B2         # ???
  #
  # Gap
  #
  MCYCLE   = 0xB00         # Always 64bit. For RV32, higher bits can be accessed via MCYCLEH
  #
  # Gap
  #
  MINSTRET      = 0xB02          # Always 64bit. For RV32, higher bits can be accessed via MINSTRETH
  MHPMCOUNTER3  = 0xB03          # Always 64bit. For RV32, higher bits can be accessed via MHPMCOUNTERxH
  MHPMCOUNTER4  = 0xB04          # Always 64bit. For RV32, higher bits can be accessed via MHPMCOUNTERxH
  MHPMCOUNTER5  = 0xB05          # Always 64bit. For RV32, higher bits can be accessed via MHPMCOUNTERxH
  MHPMCOUNTER6  = 0xB06          # Always 64bit. For RV32, higher bits can be accessed via MHPMCOUNTERxH
  MHPMCOUNTER7  = 0xB07          # Always 64bit. For RV32, higher bits can be accessed via MHPMCOUNTERxH
  MHPMCOUNTER8  = 0xB08          # Always 64bit. For RV32, higher bits can be accessed via MHPMCOUNTERxH
  MHPMCOUNTER9  = 0xB09          # Always 64bit. For RV32, higher bits can be accessed via MHPMCOUNTERxH
  MHPMCOUNTER10 = 0xB0A          # Always 64bit. For RV32, higher bits can be accessed via MHPMCOUNTERxH
  MHPMCOUNTER11 = 0xB0B          # Always 64bit. For RV32, higher bits can be accessed via MHPMCOUNTERxH
  MHPMCOUNTER12 = 0xB0C          # Always 64bit. For RV32, higher bits can be accessed via MHPMCOUNTERxH
  MHPMCOUNTER13 = 0xB0D          # Always 64bit. For RV32, higher bits can be accessed via MHPMCOUNTERxH
  MHPMCOUNTER14 = 0xB0E          # Always 64bit. For RV32, higher bits can be accessed via MHPMCOUNTERxH
  MHPMCOUNTER15 = 0xB0F          # Always 64bit. For RV32, higher bits can be accessed via MHPMCOUNTERxH
  MHPMCOUNTER16 = 0xB10          # Always 64bit. For RV32, higher bits can be accessed via MHPMCOUNTERxH
  MHPMCOUNTER17 = 0xB11          # Always 64bit. For RV32, higher bits can be accessed via MHPMCOUNTERxH
  MHPMCOUNTER18 = 0xB12          # Always 64bit. For RV32, higher bits can be accessed via MHPMCOUNTERxH
  MHPMCOUNTER19 = 0xB13          # Always 64bit. For RV32, higher bits can be accessed via MHPMCOUNTERxH
  MHPMCOUNTER20 = 0xB14          # Always 64bit. For RV32, higher bits can be accessed via MHPMCOUNTERxH
  MHPMCOUNTER21 = 0xB15          # Always 64bit. For RV32, higher bits can be accessed via MHPMCOUNTERxH
  MHPMCOUNTER22 = 0xB16          # Always 64bit. For RV32, higher bits can be accessed via MHPMCOUNTERxH
  MHPMCOUNTER23 = 0xB17          # Always 64bit. For RV32, higher bits can be accessed via MHPMCOUNTERxH
  MHPMCOUNTER24 = 0xB18          # Always 64bit. For RV32, higher bits can be accessed via MHPMCOUNTERxH
  MHPMCOUNTER25 = 0xB19          # Always 64bit. For RV32, higher bits can be accessed via MHPMCOUNTERxH
  MHPMCOUNTER26 = 0xB1A          # Always 64bit. For RV32, higher bits can be accessed via MHPMCOUNTERxH
  MHPMCOUNTER27 = 0xB1B          # Always 64bit. For RV32, higher bits can be accessed via MHPMCOUNTERxH
  MHPMCOUNTER28 = 0xB1C          # Always 64bit. For RV32, higher bits can be accessed via MHPMCOUNTERxH
  MHPMCOUNTER29 = 0xB1D          # Always 64bit. For RV32, higher bits can be accessed via MHPMCOUNTERxH
  MHPMCOUNTER30 = 0xB1E          # Always 64bit. For RV32, higher bits can be accessed via MHPMCOUNTERxH
  MHPMCOUNTER31 = 0xB1F          # Always 64bit. For RV32, higher bits can be accessed via MHPMCOUNTERxH
  #
  # Gap
  #
  MCYCLEH     = 0xB80       # Higher 32-bits of MCYCLE (needed for RV32)
  #
  # Gap
  #
  MINSTRETH      = 0xB82          # Higher 32-bits of MINSTRET (needed for RV32)
  MHPMCOUNTER3H  = 0xB83          # Higher 32-bits of MHPMCOUNTERx (needed for RV32)
  MHPMCOUNTER4H  = 0xB84          # Higher 32-bits of MHPMCOUNTERx (needed for RV32)
  MHPMCOUNTER5H  = 0xB85          # Higher 32-bits of MHPMCOUNTERx (needed for RV32)
  MHPMCOUNTER6H  = 0xB86          # Higher 32-bits of MHPMCOUNTERx (needed for RV32)
  MHPMCOUNTER7H  = 0xB87          # Higher 32-bits of MHPMCOUNTERx (needed for RV32)
  MHPMCOUNTER8H  = 0xB88          # Higher 32-bits of MHPMCOUNTERx (needed for RV32)
  MHPMCOUNTER9H  = 0xB89          # Higher 32-bits of MHPMCOUNTERx (needed for RV32)
  MHPMCOUNTER10H = 0xB8A          # Higher 32-bits of MHPMCOUNTERx (needed for RV32)
  MHPMCOUNTER11H = 0xB8B          # Higher 32-bits of MHPMCOUNTERx (needed for RV32)
  MHPMCOUNTER12H = 0xB8C          # Higher 32-bits of MHPMCOUNTERx (needed for RV32)
  MHPMCOUNTER13H = 0xB8D          # Higher 32-bits of MHPMCOUNTERx (needed for RV32)
  MHPMCOUNTER14H = 0xB8E          # Higher 32-bits of MHPMCOUNTERx (needed for RV32)
  MHPMCOUNTER15H = 0xB8F          # Higher 32-bits of MHPMCOUNTERx (needed for RV32)
  MHPMCOUNTER16H = 0xB90          # Higher 32-bits of MHPMCOUNTERx (needed for RV32)
  MHPMCOUNTER17H = 0xB91          # Higher 32-bits of MHPMCOUNTERx (needed for RV32)
  MHPMCOUNTER18H = 0xB92          # Higher 32-bits of MHPMCOUNTERx (needed for RV32)
  MHPMCOUNTER19H = 0xB93          # Higher 32-bits of MHPMCOUNTERx (needed for RV32)
  MHPMCOUNTER20H = 0xB94          # Higher 32-bits of MHPMCOUNTERx (needed for RV32)
  MHPMCOUNTER21H = 0xB95          # Higher 32-bits of MHPMCOUNTERx (needed for RV32)
  MHPMCOUNTER22H = 0xB96          # Higher 32-bits of MHPMCOUNTERx (needed for RV32)
  MHPMCOUNTER23H = 0xB97          # Higher 32-bits of MHPMCOUNTERx (needed for RV32)
  MHPMCOUNTER24H = 0xB98          # Higher 32-bits of MHPMCOUNTERx (needed for RV32)
  MHPMCOUNTER25H = 0xB99          # Higher 32-bits of MHPMCOUNTERx (needed for RV32)
  MHPMCOUNTER26H = 0xB9A          # Higher 32-bits of MHPMCOUNTERx (needed for RV32)
  MHPMCOUNTER27H = 0xB9B          # Higher 32-bits of MHPMCOUNTERx (needed for RV32)
  MHPMCOUNTER28H = 0xB9C          # Higher 32-bits of MHPMCOUNTERx (needed for RV32)
  MHPMCOUNTER29H = 0xB9D          # Higher 32-bits of MHPMCOUNTERx (needed for RV32)
  MHPMCOUNTER30H = 0xB9E          # Higher 32-bits of MHPMCOUNTERx (needed for RV32)
  MHPMCOUNTER31H = 0xB9F          # Higher 32-bits of MHPMCOUNTERx (needed for RV32)
  #
  # Gap
  #
  CYCLE         = 0xC00   # Always 64-bit. For RV32, higher bits can be accessed via CYCLEH
  TIME          = 0xC01   # Always 64-bit. For RV32, higher bits can be accessed via TIMEH
  INSTRET       = 0xC02   # Always 64-bit. For RV32, higher bits can be accessed via INSTRETH
  HPMCOUNTER3   = 0xC03   # Always 64bit. For RV32, higher bits can be accessed via HPMCOUNTERxH
  HPMCOUNTER4   = 0xC04   # Always 64bit. For RV32, higher bits can be accessed via HPMCOUNTERxH
  HPMCOUNTER5   = 0xC05   # Always 64bit. For RV32, higher bits can be accessed via HPMCOUNTERxH
  HPMCOUNTER6   = 0xC06   # Always 64bit. For RV32, higher bits can be accessed via HPMCOUNTERxH
  HPMCOUNTER7   = 0xC07   # Always 64bit. For RV32, higher bits can be accessed via HPMCOUNTERxH
  HPMCOUNTER8   = 0xC08   # Always 64bit. For RV32, higher bits can be accessed via HPMCOUNTERxH
  HPMCOUNTER9   = 0xC09   # Always 64bit. For RV32, higher bits can be accessed via HPMCOUNTERxH
  HPMCOUNTER10  = 0xC0A   # Always 64bit. For RV32, higher bits can be accessed via HPMCOUNTERxH
  HPMCOUNTER11  = 0xC0B   # Always 64bit. For RV32, higher bits can be accessed via HPMCOUNTERxH
  HPMCOUNTER12  = 0xC0C   # Always 64bit. For RV32, higher bits can be accessed via HPMCOUNTERxH
  HPMCOUNTER13  = 0xC0D   # Always 64bit. For RV32, higher bits can be accessed via HPMCOUNTERxH
  HPMCOUNTER14  = 0xC0E   # Always 64bit. For RV32, higher bits can be accessed via HPMCOUNTERxH
  HPMCOUNTER15  = 0xC0F   # Always 64bit. For RV32, higher bits can be accessed via HPMCOUNTERxH
  HPMCOUNTER16  = 0xC10   # Always 64bit. For RV32, higher bits can be accessed via HPMCOUNTERxH
  HPMCOUNTER17  = 0xC11   # Always 64bit. For RV32, higher bits can be accessed via HPMCOUNTERxH
  HPMCOUNTER18  = 0xC12   # Always 64bit. For RV32, higher bits can be accessed via HPMCOUNTERxH
  HPMCOUNTER19  = 0xC13   # Always 64bit. For RV32, higher bits can be accessed via HPMCOUNTERxH
  HPMCOUNTER20  = 0xC14   # Always 64bit. For RV32, higher bits can be accessed via HPMCOUNTERxH
  HPMCOUNTER21  = 0xC15   # Always 64bit. For RV32, higher bits can be accessed via HPMCOUNTERxH
  HPMCOUNTER22  = 0xC16   # Always 64bit. For RV32, higher bits can be accessed via HPMCOUNTERxH
  HPMCOUNTER23  = 0xC17   # Always 64bit. For RV32, higher bits can be accessed via HPMCOUNTERxH
  HPMCOUNTER24  = 0xC18   # Always 64bit. For RV32, higher bits can be accessed via HPMCOUNTERxH
  HPMCOUNTER25  = 0xC19   # Always 64bit. For RV32, higher bits can be accessed via HPMCOUNTERxH
  HPMCOUNTER26  = 0xC1A   # Always 64bit. For RV32, higher bits can be accessed via HPMCOUNTERxH
  HPMCOUNTER27  = 0xC1B   # Always 64bit. For RV32, higher bits can be accessed via HPMCOUNTERxH
  HPMCOUNTER28  = 0xC1C   # Always 64bit. For RV32, higher bits can be accessed via HPMCOUNTERxH
  HPMCOUNTER29  = 0xC1D   # Always 64bit. For RV32, higher bits can be accessed via HPMCOUNTERxH
  HPMCOUNTER30  = 0xC1E   # Always 64bit. For RV32, higher bits can be accessed via HPMCOUNTERxH
  HPMCOUNTER31  = 0xC1F   # Always 64bit. For RV32, higher bits can be accessed via HPMCOUNTERxH
  #
  # Gap
  #
  CYCLEH        = 0xC80   # Higher 32-bit of CYCLE (needed for RV32)
  TIMEH         = 0xC81   # Higher 32-bit of TIME (needed for RV32)
  INSTRETH      = 0xC82   # Higher 32-bit of INSTRET (needed for RV32)
  HPMCOUNTER3H  = 0xC83   # Higher 32-bits of HPMCOUNTERx (Needed for RV32)
  HPMCOUNTER4H  = 0xC84   # Higher 32-bits of HPMCOUNTERx (Needed for RV32)
  HPMCOUNTER5H  = 0xC85   # Higher 32-bits of HPMCOUNTERx (Needed for RV32)
  HPMCOUNTER6H  = 0xC86   # Higher 32-bits of HPMCOUNTERx (Needed for RV32)
  HPMCOUNTER7H  = 0xC87   # Higher 32-bits of HPMCOUNTERx (Needed for RV32)
  HPMCOUNTER8H  = 0xC88   # Higher 32-bits of HPMCOUNTERx (Needed for RV32)
  HPMCOUNTER9H  = 0xC89   # Higher 32-bits of HPMCOUNTERx (Needed for RV32)
  HPMCOUNTER10H = 0xC8A   # Higher 32-bits of HPMCOUNTERx (Needed for RV32)
  HPMCOUNTER11H = 0xC8B   # Higher 32-bits of HPMCOUNTERx (Needed for RV32)
  HPMCOUNTER12H = 0xC8C   # Higher 32-bits of HPMCOUNTERx (Needed for RV32)
  HPMCOUNTER13H = 0xC8D   # Higher 32-bits of HPMCOUNTERx (Needed for RV32)
  HPMCOUNTER14H = 0xC8E   # Higher 32-bits of HPMCOUNTERx (Needed for RV32)
  HPMCOUNTER15H = 0xC8F   # Higher 32-bits of HPMCOUNTERx (Needed for RV32)
  HPMCOUNTER16H = 0xC90   # Higher 32-bits of HPMCOUNTERx (Needed for RV32)
  HPMCOUNTER17H = 0xC91   # Higher 32-bits of HPMCOUNTERx (Needed for RV32)
  HPMCOUNTER18H = 0xC92   # Higher 32-bits of HPMCOUNTERx (Needed for RV32)
  HPMCOUNTER19H = 0xC93   # Higher 32-bits of HPMCOUNTERx (Needed for RV32)
  HPMCOUNTER20H = 0xC94   # Higher 32-bits of HPMCOUNTERx (Needed for RV32)
  HPMCOUNTER21H = 0xC95   # Higher 32-bits of HPMCOUNTERx (Needed for RV32)
  HPMCOUNTER22H = 0xC96   # Higher 32-bits of HPMCOUNTERx (Needed for RV32)
  HPMCOUNTER23H = 0xC97   # Higher 32-bits of HPMCOUNTERx (Needed for RV32)
  HPMCOUNTER24H = 0xC98   # Higher 32-bits of HPMCOUNTERx (Needed for RV32)
  HPMCOUNTER25H = 0xC99   # Higher 32-bits of HPMCOUNTERx (Needed for RV32)
  HPMCOUNTER26H = 0xC9A   # Higher 32-bits of HPMCOUNTERx (Needed for RV32)
  HPMCOUNTER27H = 0xC9B   # Higher 32-bits of HPMCOUNTERx (Needed for RV32)
  HPMCOUNTER28H = 0xC9C   # Higher 32-bits of HPMCOUNTERx (Needed for RV32)
  HPMCOUNTER29H = 0xC9D   # Higher 32-bits of HPMCOUNTERx (Needed for RV32)
  HPMCOUNTER30H = 0xC9E   # Higher 32-bits of HPMCOUNTERx (Needed for RV32)
  HPMCOUNTER31H = 0xC9F   # Higher 32-bits of HPMCOUNTERx (Needed for RV32)
  #
  # Gap
  #
  MVENDORID = 0xF11       # 32/64-bit. Depends on RV32/64
  MARCHID   = 0xF12       # 32/64-bit. Depends on RV32/64
  MIMPID    = 0xF13       # 32/64-bit. Depends on RV32/64
  MHARTID   = 0xF14       # 32/64-bit. Depends on RV32/64
  #
  # Gap
  #
  X0        = 0x1000              # 32/64-bit. Depends on RV32/64
  X1        = 0x1001              # 32/64-bit. Depends on RV32/64
  X2        = 0x1002              # 32/64-bit. Depends on RV32/64
  X3        = 0x1003              # 32/64-bit. Depends on RV32/64
  X4        = 0x1004              # 32/64-bit. Depends on RV32/64
  X5        = 0x1005              # 32/64-bit. Depends on RV32/64
  X6        = 0x1006              # 32/64-bit. Depends on RV32/64
  X7        = 0x1007              # 32/64-bit. Depends on RV32/64
  X8        = 0x1008              # 32/64-bit. Depends on RV32/64
  X9        = 0x1009              # 32/64-bit. Depends on RV32/64
  X10       = 0x100A              # 32/64-bit. Depends on RV32/64
  X11       = 0x100B              # 32/64-bit. Depends on RV32/64
  X12       = 0x100C              # 32/64-bit. Depends on RV32/64
  X13       = 0x100D              # 32/64-bit. Depends on RV32/64
  X14       = 0x100E              # 32/64-bit. Depends on RV32/64
  X15       = 0x100F              # 32/64-bit. Depends on RV32/64
  X16       = 0x1010              # 32/64-bit. Depends on RV32/64
  X17       = 0x1011              # 32/64-bit. Depends on RV32/64
  X18       = 0x1012              # 32/64-bit. Depends on RV32/64
  X19       = 0x1013              # 32/64-bit. Depends on RV32/64
  X20       = 0x1014              # 32/64-bit. Depends on RV32/64
  X21       = 0x1015              # 32/64-bit. Depends on RV32/64
  X22       = 0x1016              # 32/64-bit. Depends on RV32/64
  X23       = 0x1017              # 32/64-bit. Depends on RV32/64
  X24       = 0x1018              # 32/64-bit. Depends on RV32/64
  X25       = 0x1019              # 32/64-bit. Depends on RV32/64
  X26       = 0x101A              # 32/64-bit. Depends on RV32/64
  X27       = 0x101B              # 32/64-bit. Depends on RV32/64
  X28       = 0x101C              # 32/64-bit. Depends on RV32/64
  X29       = 0x101D              # 32/64-bit. Depends on RV32/64
  X30       = 0x101E              # 32/64-bit. Depends on RV32/64
  X31       = 0x101F              # 32/64-bit. Depends on RV32/64
  #
  # Gap
  #
  F0  = 0x1020             # Length depends on length of floating point unit
  F1  = 0x1021             # Length depends on length of floating point unit
  F2  = 0x1022             # Length depends on length of floating point unit
  F3  = 0x1023             # Length depends on length of floating point unit
  F4  = 0x1024             # Length depends on length of floating point unit
  F5  = 0x1025             # Length depends on length of floating point unit
  F6  = 0x1026             # Length depends on length of floating point unit
  F7  = 0x1027             # Length depends on length of floating point unit
  F8  = 0x1028             # Length depends on length of floating point unit
  F9  = 0x1029             # Length depends on length of floating point unit
  F10 = 0x102A             # Length depends on length of floating point unit
  F11 = 0x102B             # Length depends on length of floating point unit
  F12 = 0x102C             # Length depends on length of floating point unit
  F13 = 0x102D             # Length depends on length of floating point unit
  F14 = 0x102E             # Length depends on length of floating point unit
  F15 = 0x102F             # Length depends on length of floating point unit
  F16 = 0x1020             # Length depends on length of floating point unit
  F17 = 0x1031             # Length depends on length of floating point unit
  F18 = 0x1032             # Length depends on length of floating point unit
  F19 = 0x1033             # Length depends on length of floating point unit
  F20 = 0x1034             # Length depends on length of floating point unit
  F21 = 0x1035             # Length depends on length of floating point unit
  F22 = 0x1036             # Length depends on length of floating point unit
  F23 = 0x1037             # Length depends on length of floating point unit
  F24 = 0x1038             # Length depends on length of floating point unit
  F25 = 0x1039             # Length depends on length of floating point unit
  F26 = 0x103A             # Length depends on length of floating point unit
  F27 = 0x103B             # Length depends on length of floating point unit
  F28 = 0x103C             # Length depends on length of floating point unit
  F29 = 0x103D             # Length depends on length of floating point unit
  F30 = 0x103E             # Length depends on length of floating point unit
  F31 = 0x103F             # Length depends on length of floating point unit
  #
  # Gap
  #
  V0  = 0x1040            # Length = ???
  V1  = 0x1041            # Length = ???
  V2  = 0x1042            # Length = ???
  V3  = 0x1043            # Length = ???
  V4  = 0x1044            # Length = ???
  V5  = 0x1045            # Length = ???
  V6  = 0x1046            # Length = ???
  V7  = 0x1047            # Length = ???
  V8  = 0x1048            # Length = ???
  V9  = 0x1049            # Length = ???
  V10 = 0x104A            # Length = ???
  V11 = 0x104B            # Length = ???
  V12 = 0x104C            # Length = ???
  V13 = 0x104D            # Length = ???
  V14 = 0x104E            # Length = ???
  V15 = 0x104F            # Length = ???
  V16 = 0x1050            # Length = ???
  V17 = 0x1051            # Length = ???
  V18 = 0x1052            # Length = ???
  V19 = 0x1053            # Length = ???
  V20 = 0x1054            # Length = ???
  V21 = 0x1055            # Length = ???
  V22 = 0x1056            # Length = ???
  V23 = 0x1057            # Length = ???
  V24 = 0x1058            # Length = ???
  V25 = 0x1059            # Length = ???
  V26 = 0x105A            # Length = ???
  V27 = 0x105B            # Length = ???
  V28 = 0x105C            # Length = ???
  V29 = 0x105D            # Length = ???
  V30 = 0x105E            # Length = ???
  V31 = 0x105F            # Length = ???
  VP0 = 0x1060            # Length = ???
  VP1 = 0x1061            # Length = ???
  VP2 = 0x1062            # Length = ???
  VP3 = 0x1063            # Length = ???
  VP4 = 0x1064            # Length = ???
  VP5 = 0x1065            # Length = ???
  VP6 = 0x1066            # Length = ???
  VP7 = 0x1067            # Length = ???
  #
  # Gap
  #
  PC  = 0x1080            # 32/64-bit. Depends on RV32/64
  # Reg indexes 0x10000 - 0x1FFFF must not be used for RISC-V. They are reserved for DLL internal use

#/*********************************************************************
#*
#*       ARM_V8AR_REG
#*
#*  Class description
#*    This class is the python equivalent of the C enum "JLINK_ARM_V8AR_REG"
#*    from JLINKARM_Const.h
#*
#**********************************************************************
#*/
class ARM_V8AR_REG:
  #
  # Registers for ARMv8-AR architecture (Cortex-A32, A53, A57, A72, ...)
  # For registers > 32-bit, using the old Read/Write Register functions only the lower 32-bit can be read/written
  # For writes, this would result in the upper 32-bits being written as 0s
  # It is recommended to use the new 64-bit Read/Write register functions
  #
  #  GPR, PC, SP, ... (64-bit regs)
  #  *_EL12    => EL12 aliases of EL1 special-purpose registers (See [1] C5.1.5 Moves to and from Special-purpose registers)
  #  SPSR_EL12 => Accesses SPSR_EL1
  #  ELR_EL12  => Accesses ELR_EL1
  #  Not listed here as they do not make any sense within J-Link...
  #
  #  SP_EL3 => For now it returns the same value as SP_EL2 because neither the ARM doc nor the GCC assembler have an instruction for SP_EL3...
  #
  R0        = 0
  R1        = 1
  R2        = 2
  R3        = 3
  R4        = 4
  R5        = 5
  R6        = 6
  R7        = 7
  R8        = 8
  R9        = 9
  R10       = 10
  R11       = 11
  R12       = 12
  R13       = 13
  R14       = 14
  R15       = 15
  R16       = 16
  R17       = 17
  R18       = 18
  R19       = 19
  R20       = 20
  R21       = 21
  R22       = 22
  R23       = 23
  R24       = 24
  R25       = 25
  R26       = 26
  R27       = 27
  R28       = 28
  R29       = 29
  R30       = 30
  R31       = 31
  SP        = 32
  PC        = 33
  ELR_EL1   = 34
  ELR_EL2   = 35
  ELR_EL3   = 36
  SP_EL0    = 37
  SP_EL1    = 38
  SP_EL2    = 39
  SP_EL3    = 40
  CPSR      = 41
  SPSR_abt  = 42
  SPSR_EL1  = 43
  SPSR_EL2  = 44
  SPSR_EL3  = 45
  SPSR_fiq  = 46
  SPSR_irq  = 47
  SPSR_und  = 48
  #
  # Floating point (32-bit)
  #
  FPCR      = 49
  FPSR      = 50
  #
  # Floating point (128-bit, split into LOW/HIGH 64-bit parts)
  #
  V0_LOW      = 51
  V0_HIGH     = 52
  V1_LOW      = 53
  V1_HIGH     = 54
  V2_LOW      = 55
  V2_HIGH     = 56
  V3_LOW      = 57
  V3_HIGH     = 58
  V4_LOW      = 59
  V4_HIGH     = 60
  V5_LOW      = 61
  V5_HIGH     = 62
  V6_LOW      = 63
  V6_HIGH     = 64
  V7_LOW      = 65
  V7_HIGH     = 66
  V8_LOW      = 67
  V8_HIGH     = 68
  V9_LOW      = 69
  V9_HIGH     = 70
  V10_LOW     = 71
  V10_HIGH    = 72
  V11_LOW     = 73
  V11_HIGH    = 74
  V12_LOW     = 75
  V12_HIGH    = 76
  V13_LOW     = 77
  V13_HIGH    = 78
  V14_LOW     = 79
  V14_HIGH    = 80
  V15_LOW     = 81
  V15_HIGH    = 82
  V16_LOW     = 83
  V16_HIGH    = 84
  V17_LOW     = 85
  V17_HIGH    = 86
  V18_LOW     = 87
  V18_HIGH    = 88
  V19_LOW     = 89
  V19_HIGH    = 90
  V20_LOW     = 91
  V20_HIGH    = 92
  V21_LOW     = 93
  V21_HIGH    = 94
  V22_LOW     = 95
  V22_HIGH    = 96
  V23_LOW     = 97
  V23_HIGH    = 98
  V24_LOW     = 99
  V24_HIGH    = 100
  V25_LOW     = 101
  V25_HIGH    = 102
  V26_LOW     = 103
  V26_HIGH    = 104
  V27_LOW     = 105
  V27_HIGH    = 106
  V28_LOW     = 107
  V28_HIGH    = 108
  V29_LOW     = 109
  V29_HIGH    = 110
  V30_LOW     = 111
  V30_HIGH    = 112
  V31_LOW     = 113
  V31_HIGH    = 114
  #
  # Encoding of REG_MISC:
  # [63:32]  Reserved for future use (currently 0)
  # [31:4]  Reserved for future use (currently 0)
  # [3:0]   ELAArchSupport
  #
  # ELAArchSupport:
  #   All: AArch32
  #   All: AArch32
  #   All: AArch32
  #   All: AArch32
  #   All: AArch32
  #   All: AArch32
  #   All: AArch32
  #   All: AArch32
  #   EL0,1,2: AArch32. Others: AArch64
  #   EL0,1,2: AArch32. Others: AArch64
  #   EL0,1,2: AArch32. Others: AArch64
  #   EL0,1,2: AArch32. Others: AArch64
  #   EL0,1: AArch32. Others: AArch64
  #   EL0,1: AArch32. Others: AArch64
  #   EL0: AArch32. Others: AArch64
  #   All: AArch64
  #
  JMISC       = 115  # J-Link specific 64-bit register which is used to add some kind of extra info that is usually only visible via the debug regs.
  #
  # Pseudo registers for AArch32 compatibility mode
  # DLL will map them internally to AArch64 regs
  #
  AARCH32_R0          = 116
  AARCH32_R1          = 117
  AARCH32_R2          = 118
  AARCH32_R3          = 119
  AARCH32_R4          = 120
  AARCH32_R5          = 111
  AARCH32_R6          = 112
  AARCH32_R7          = 113
  AARCH32_R8_USR      = 114
  AARCH32_R9_USR      = 115
  AARCH32_R10_USR     = 116
  AARCH32_R11_USR     = 117
  AARCH32_R12_USR     = 118
  AARCH32_R13_USR     = 119
  AARCH32_R14_USR     = 120
  AARCH32_R13_HYP     = 121
  AARCH32_R13_IRQ     = 122
  AARCH32_R14_IRQ     = 123
  AARCH32_R13_SVC     = 124
  AARCH32_R14_SVC     = 125
  AARCH32_R13_ABT     = 126
  AARCH32_R14_ABT     = 127
  AARCH32_R13_UND     = 128
  AARCH32_R14_UND     = 129
  AARCH32_R8_FIQ      = 130
  AARCH32_R9_FIQ      = 131
  AARCH32_R10_FIQ     = 132
  AARCH32_R11_FIQ     = 133
  AARCH32_R12_FIQ     = 134
  AARCH32_R13_FIQ     = 135
  AARCH32_R14_FIQ     = 136
  AARCH32_PC          = 137
  AARCH32_ELR_HYP     = 138
  AARCH32_CPSR        = 139
  AARCH32_SPSR_ABT    = 140
  AARCH32_SPSR_SVC    = 141
  AARCH32_SPSR_HYP    = 142
  AARCH32_SPSR_FIQ    = 143
  AARCH32_SPSR_IRQ    = 144
  AARCH32_SPSR_UND    = 145
  AARCH32_FPSCR       = 146
  AARCH32_Q0_LOW      = 147
  AARCH32_Q0_HIGH     = 148
  AARCH32_Q1_LOW      = 149
  AARCH32_Q1_HIGH     = 150
  AARCH32_Q2_LOW      = 151
  AARCH32_Q2_HIGH     = 152
  AARCH32_Q3_LOW      = 153
  AARCH32_Q3_HIGH     = 154
  AARCH32_Q4_LOW      = 155
  AARCH32_Q4_HIGH     = 156
  AARCH32_Q5_LOW      = 157
  AARCH32_Q5_HIGH     = 158
  AARCH32_Q6_LOW      = 159
  AARCH32_Q6_HIGH     = 160
  AARCH32_Q7_LOW      = 161
  AARCH32_Q7_HIGH     = 162
  AARCH32_Q8_LOW      = 163
  AARCH32_Q8_HIGH     = 164
  AARCH32_Q9_LOW      = 165
  AARCH32_Q9_HIGH     = 166
  AARCH32_Q10_LOW     = 167
  AARCH32_Q10_HIGH    = 168
  AARCH32_Q11_LOW     = 169
  AARCH32_Q11_HIGH    = 170
  AARCH32_Q12_LOW     = 171
  AARCH32_Q12_HIGH    = 172
  AARCH32_Q13_LOW     = 173
  AARCH32_Q13_HIGH    = 174
  AARCH32_Q14_LOW     = 175
  AARCH32_Q14_HIGH    = 176
  AARCH32_Q15_LOW     = 177
  AARCH32_Q15_HIGH    = 178
  AARCH32_R8          = 179         # Current registers (automatically mapped to USR, IRQ, FIQ, ... by DLL)
  AARCH32_R9          = 180
  AARCH32_R10         = 181
  AARCH32_R11         = 182
  AARCH32_R12         = 183
  AARCH32_R13         = 184
  AARCH32_R14         = 185

#/*********************************************************************
#*
#*       EMU_CAP
#*
#*  Class description
#*    This class is the python equivalent of the C defines "JLINKARM_EMU_CAP_*"
#*    from JLINKARM_Const.h
#*
#**********************************************************************
#*/
class EMU_CAP():
  RESERVED            =   (1 <<  0)     # Always 1
  GET_HW_VERSION      =   (1 <<  1)     # Supports command "EMU_CMD_GET_HARDWARE_VERSION"
  WRITE_DCC           =   (1 <<  2)     # Supports command "EMU_CMD_WRITE_DCC"
  ADAPTIVE_CLOCKING   =   (1 <<  3)     # Supports adaptive clocking
  READ_CONFIG         =   (1 <<  4)     # Supports command "EMU_CMD_READ_CONFIG"
  WRITE_CONFIG        =   (1 <<  5)     # Supports command "EMU_CMD_WRITE_CONFIG"
  TRACE_ARM79         =   (1 <<  6)     # OBSOLETE and not used anymore. Use RAWTRACE instead.
  WRITE_MEM           =   (1 <<  7)     # Supports command "EMU_CMD_WRITE_MEM"
  READ_MEM            =   (1 <<  8)     # Supports command "EMU_CMD_READ_MEM"
  SPEED_INFO          =   (1 <<  9)     # Supports command "EMU_CMD_GET_SPEED"
  EXEC_CODE           =   (1 << 10)     # Supports command "EMU_CMD_CODE_..."
  GET_MAX_BLOCK_SIZE  =   (1 << 11)     # Supports command "EMU_CMD_CODE_..."
  GET_HW_INFO         =   (1 << 12)     # Supports command "EMU_CMD_GET_HW_INFO"
  SET_KS_POWER        =   (1 << 13)     # Supports command "EMU_CMD_SET_KS_POWER"
  RESET_STOP_TIMED    =   (1 << 14)     # Supports command "EMU_CMD_HW_RELEASE_RESET_STOP_TIMED"
  GET_LICENSE_INFO    =   (1 << 15)     # Supports command "EMU_CMD_GET_LICENSE_INFO"
  MEASURE_RTCK_REACT  =   (1 << 16)     # Supports command "EMU_CMD_MEASURE_RTCK_REACT"
  SELECT_IF           =   (1 << 17)     # Supports command "EMU_CMD_HW_SELECT_IF"
  RW_MEM_ARM79        =   (1 << 18)     # Supports command "EMU_CMD_WRITE_MEM_ARM79", "CMD_READ_MEM_ARM79"
  GET_COUNTERS        =   (1 << 19)     # Supports command "EMU_CMD_GET_COUNTERS"
  READ_DCC            =   (1 << 20)     # Supports command "EMU_CMD_READ_DCC"
  GET_CPU_CAPS        =   (1 << 21)     # Supports command "EMU_CMD_GET_CPU_CAPS"
  EXEC_CPU_CMD        =   (1 << 22)     # Supports command "EMU_CMD_EXEC_CPU_CMD"
  SWO                 =   (1 << 23)     # Supports command "EMU_CMD_SWO"
  WRITE_DCC_EX        =   (1 << 24)     # Supports command "EMU_CMD_WRITE_DCC_EX"
  UPDATE_FIRMWARE_EX  =   (1 << 25)     # Supports command "EMU_CMD_UPDATE_FIRMWARE_EX"
  FILE_IO             =   (1 << 26)     # Supports command "EMU_CMD_FILE_IO"
  REGISTER            =   (1 << 27)     # Supports command "EMU_CMD_REGISTER"
  INDICATORS          =   (1 << 28)     # Supports command "EMU_CMD_INDICATORS"
  TEST_NET_SPEED      =   (1 << 29)     # Supports command "EMU_CMD_TEST_NET_SPEED"
  RAWTRACE            =   (1 << 30)     # Supports command "EMU_CMD_RAWTRACE"
  GET_CAPS_EX         =   (1 << 31)     # Supports command "EMU_CMD_GET_CAPS_EX"

#/*********************************************************************
#*
#*       RTTERMINAL_CMD
#*
#*  Class description
#*    This class is the python equivalent of the C defines "JLINKARM_RTTERMINAL_CMD_*"
#*    from JLINKARM_Const.h
#*
#**********************************************************************
#*/
class RTTERMINAL_CMD:
  START     = 0
  STOP      = 1
  GETDESC   = 2
  GETNUMBUF = 3
  GETSTAT   = 4

#/*********************************************************************
#*
#*       RTTERMINAL_BUFFER_DIR
#*
#*  Class description
#*    This class is the python equivalent of the C defines "JLINKARM_RTTERMINAL_BUFFER_*"
#*    from JLINKARM_Const.h
#*
#**********************************************************************
#*/
class RTTERMINAL_BUFFER_DIR:
  UP     = 0
  DOWN   = 1

#/*********************************************************************
#*
#*       STRACE_CNT_TYPE
#*
#*  Class description
#*    This class is the python equivalent of the C defines "JLINK_STRACE_CNT_TYPE_*"
#*    from JLINKARM_Const.h
#*
#**********************************************************************
#*/
class STRACE_CNT_TYPE:
  FETCHED             =  0x0   # Get counter of how many times the instruction at <Addr> was fetched.
  EXEC                =  0x1   # Get counter of how many times the instruction at <Addr> was fetched and executed.
  SKIP                =  0x2   # Get counter of how many times the instruction at <Addr> was fetched but not executed (skipped).
  #-------------------=  0x3   # 3 is reserved.
  TOTAL_FETCHED       =  0x4   # Sum of all fetch counts of all addresses we have so far. <Addr> parameter is don't care.
  TOTAL_EXEC          =  0x5   # Sum of all exec counts of all addresses we have so far. <Addr> parameter is don't care.
  TOTAL_SKIP          =  0x6   # Sum of all skip counts of all addresses we have so far. <Addr> parameter is don't care.
  TOTAL_NUM_INSTS     =  0x7   # Number of instructions which were ever fetched of all addresses we have so far. <Addr> parameter is don't care.
  FETCHED_EXEC        =  0x8   # Get the fetched and exec counters + their totals. Format: Fetch counters | fetch count total | exec counters | exec count total
  FETCHED_SKIP        =  0x9   # Get the fetched and skip counters + their totals. Format: Fetch counters | fetch count total | skip counters | skip count total
  EXEC_SKIP           =  0xA   # Get the exec and skip counters + their totals. Format: Exec counters | exec count total | skip counters | skip count total
  FETCHED_EXEC_SKIP   =  0xB   # Get the fetched, exec and skip counters + their totals. Format: Fetch counters | fetch count total | exec counters | exec count total | skip counters | skip count total

#/*********************************************************************
#*
#*       Public classes - Structs and structlikes
#*
#**********************************************************************
#*/

#/*********************************************************************
#*
#*       CONNECTION_INFO
#*
#*  Class description
#*    This class is the python equivalent of the C struct "JLINKARM_EMU_CONNECT_INFO"
#*    from JLINKARM_Const.h
#*
#**********************************************************************
#*/
class CONNECTION_INFO():
  def __init__(self):       # Constructor
    self.SN         = None
    self.HostIF     = None
    self.sIP        = None
    self.HWVersion  = None
    self.abMACAddr  = None
    self.sProduct   = None
    self.sNickname  = None
    self.sFW        = None

#/*********************************************************************
#*
#*       C_CONNECTION_INFO
#*
#*  Class description
#*    This class is the python equivalent of the C struct "JLINKARM_EMU_CONNECT_INFO"
#*    from JLINKARM_Const.h using C types of the ctypes module.
#*    Instances of this class are only used to be passed directly to the DLL.
#*    After that, conversion to the class CONNECTION_INFO should be done, so the data can be handled in a pythonic way.
#*
#**********************************************************************
#*/
class C_CONNECTION_INFO(Structure):                # JLINKARM_EMU_CONNECT_INFO
  _fields_ = [
    ("SerialNumber",             c_uint32       ),  # This is the serial number reported in the discovery process, which is the "true serial number" for newer J-Links and 123456 for older J-Links.
    ("Connection",               c_uint32       ),  # Either JLINKARM_HOSTIF_USB = 1 or JLINKARM_HOSTIF_IP = 2
    ("USBAddr",                  c_uint32       ),  # USB Addr. Default is 0, values of 0..3 are permitted (Only filled if for J-Links connected via USB)
    ("aIPAddr",                  c_byte   * 16  ),  # IP Addr. in case emulator is connected via IP. For IP4 (current version), only the first 4 bytes are used.
    ("Time",                     c_int32        ),  # J-Link via IP only: Time period [ms] after which we have received the UDP discover answer from emulator (-1 if emulator is connected over USB)
    ("Time_us",                  c_uint64       ),  # J-Link via IP only: Time period [us] after which we have received the UDP discover answer from emulator (-1 if emulator is connected over USB)
    ("HWVersion",                c_uint32       ),  # J-Link via IP only: Hardware version of J-Link
    ("abMACAddr",                c_byte   * 6   ),  # J-Link via IP only: MAC Addr
    ("acProduct",                c_char   * 32  ),  # Product name
    ("acNickName",               c_char   * 32  ),  # J-Link via IP only: Nickname of J-Link
    ("acFWString",               c_char   * 112 ),  # J-Link via IP only: Firmware string of J-Link
    ("IsDHCPAssignedIP",         c_char         ),  # J-Link via IP only: Is J-Link configured for IP address reception via DHCP?
    ("IsDHCPAssignedIPIsValid",  c_char         ),  # J-Link via IP only
    ("NumIPConnections",         c_char         ),  # J-Link via IP only: Number of IP connections which are currently established to this J-Link
    ("NumIPConnectionsIsValid",  c_char         ),  # J-Link via IP only
    ("aPadding",                 c_byte   * 34  ),  # Pad struct size to 264 bytes
  ]

#/*********************************************************************
#*
#*       MEM_ZONE_INFO
#*
#*  Class description
#*    This class is the python equivalent of the C struct "JLINK_MEM_ZONE_INFO"
#*    from JLINKARM_Const.h
#*
#**********************************************************************
#*/
class MEM_ZONE_INFO:
  def __init__(self):
    self.sName    = None
    self.sDesc    = None
    self.VirtAddr = None

#/*********************************************************************
#*
#*       C_MEM_ZONE_INFO
#*
#*  Class description
#*    This class is the python equivalent of the C struct "JLINKARM_EMU_CONNECT_INFO"
#*    from JLINKARM_Const.h using C types of the ctypes module.
#*    Instances of this class are only used to be passed directly to the DLL.
#*    After that, conversion to the class MEM_ZONE_INFO should be done, so the data can be handled in a pythonic way.
#*
#**********************************************************************
#*/
class C_MEM_ZONE_INFO:
  _fields_ = [
    ("sName",     c_char_p    ),
    ("sDesc",     c_char_p    ),
    ("VirtAddr",  c_uint64    ),
    ("abDummy",   c_byte * 16 ),  # Round up to 32 bytes. Future use. Currently 0
  ]

#/*********************************************************************
#*
#*       RTTERMINAL_START
#*
#*  Class description
#*    This class is the python equivalent of the C struct "JLINK_RTTERMINAL_START"
#*    from JLINKARM_Const.h
#*
#**********************************************************************
#*/
class RTTERMINAL_START():
  def __init__(self, ConfigBlockAddress = None): # Constructor
    self.ConfigBlockAddress = ConfigBlockAddress

#/*********************************************************************
#*
#*       C_RTTERMINAL_START
#*
#*  Class description
#*    This class is the python equivalent of the C struct "JLINK_RTTERMINAL_START"
#*    from JLINKARM_Const.h using C types of the ctypes module.
#*    Instances of this class are only used to be passed directly to the DLL.
#*    After that, conversion to the class RTTERMINAL_START should be done, so the data can be handled in a pythonic way.
#*
#**********************************************************************
#*/
class C_RTTERMINAL_START(Structure):
  _fields_ = [
    ("ConfigBlockAddress", c_uint32),  # Address of RTT block.
    ("Dummy0",             c_uint32),  # SBZ. Reserved for future use.
    ("Dummy1",             c_uint32),  # SBZ. Reserved for future use.
    ("Dummy2",             c_uint32),  # SBZ. Reserved for future use.
  ]

#/*********************************************************************
#*
#*       RTTERMINAL_STOP
#*
#*  Class description
#*    This class is the python equivalent of the C struct "JLINK_RTTERMINAL_STOP"
#*    from JLINKARM_Const.h
#*
#**********************************************************************
#*/
class RTTERMINAL_STOP():
  def __init__(self, InvalidateTargetCB = None): # Constructor
    self.InvalidateTargetCB = InvalidateTargetCB


#/*********************************************************************
#*
#*       C_RTTERMINAL_STOP
#*
#*  Class description
#*    This class is the python equivalent of the C struct "JLINK_RTTERMINAL_STOP"
#*    from JLINKARM_Const.h using C types of the ctypes module.
#*    Instances of this class are only used to be passed directly to the DLL.
#*    After that, conversion to the class RTTERMINAL_STOP should be done, so the data can be handled in a pythonic way.
#*
#**********************************************************************
#*/
class C_RTTERMINAL_STOP(Structure):
  _fields_ = [
    ("InvalidateTargetCB", c_uint8     ), # If set, RTTCB will be invalidated on target.
    ("acDummy",            c_uint8 * 3 ), # SBZ. Reserved for future use.
    ("Dummy0",             c_uint32    ), # SBZ. Reserved for future use.
    ("Dummy1",             c_uint32    ), # SBZ. Reserved for future use.
    ("Dummy2",             c_uint32    ), # SBZ. Reserved for future use.
  ]

#/*********************************************************************
#*
#*       RTTERMINAL_BUFDESC
#*
#*  Class description
#*    This class is the python equivalent of the C struct "JLINK_RTTERMINAL_BUFDESC"
#*    from JLINKARM_Const.h
#*
#**********************************************************************
#*/
class RTTERMINAL_BUFDESC():
  #
  # Constructors
  #
  def __init__(self, BufferIndex = None, Direction = None):
    self.BufferIndex        = BufferIndex
    self.Direction          = Direction
    self.sName              = None
    self.SizeOfBuffer       = None
    self.Flags              = None

#/*********************************************************************
#*
#*       C_RTTERMINAL_BUFDESC
#*
#*  Class description
#*    This class is the python equivalent of the C struct "JLINK_RTTERMINAL_BUFDESC"
#*    from JLINKARM_Const.h using C types of the ctypes module.
#*    Instances of this class are only used to be passed directly to the DLL.
#*    After that, conversion to the class RTTERMINAL_BUFDESC should be done, so the data can be handled in a pythonic way.
#*
#**********************************************************************
#*/
class C_RTTERMINAL_BUFDESC(Structure):
  _fields_ = [
     ("BufferIndex",  c_int32     )        # In: Index of the buffer to get info about.
    ,("Direction",    c_uint32    )        # In: Direction of the buffer. (0 = Up; 1 = Down)
    ,("acName",       c_char * 32 )        # Out: Array for the 0-terminated name of the buffer.
    ,("SizeOfBuffer", c_uint32    )        # Out: Size of the buffer on the target.
    ,("Flags",        c_uint32    )        # Out: Flags of the buffer.
  ]

#/*********************************************************************
#*
#*       RTTERMINAL_STATUS
#*
#*  Class description
#*    This class is the python equivalent of the C struct "JLINK_RTTERMINAL_STATUS"
#*    from JLINKARM_Const.h
#*
#**********************************************************************
#*/
class RTTERMINAL_STATUS():
  #
  # Constructors
  #
  def __init__(self):
    self.NumBytesTransferred = None
    self.NumBytesRead        = None
    self.HostOverflowCount   = None
    self.IsRunning           = None
    self.NumUpBuffers        = None
    self.NumDownBuffers      = None
    self.OverflowMask        = None

#/*********************************************************************
#*
#*       C_RTTERMINAL_STATUS
#*
#*  Class description
#*    This class is the python equivalent of the C struct "JLINK_RTTERMINAL_STATUS"
#*    from JLINKARM_Const.h using C types of the ctypes module.
#*    Instances of this class are only used to be passed directly to the DLL.
#*    After that, conversion to the class RTTERMINAL_STATUS should be done, so the data can be handled in a pythonic way.
#*
#**********************************************************************
#*/
class C_RTTERMINAL_STATUS(Structure):
  _fields_ = [
    ("NumBytesTransferred", c_uint32 ),    # Out: Total number of bytes sent to client application(s)
    ("NumBytesRead",        c_uint32 ),    # Out: Total number of bytes read from the target
    ("HostOverflowCount",   c_int32  ),    # Out: Indicates a buffer overflow on the host system
    ("IsRunning",           c_int32  ),    # Out:
    ("NumUpBuffers",        c_int32  ),    # Out: Number of channels from the target which are handled by DLL.
    ("NumDownBuffers",      c_int32  ),    # Out: Number of channels to the target which are handled by DLL.
    ("OverflowMask",        c_uint32 ),    # Out: Earlier: SBZ, Since V6.93a: Indicates which buffer(s) overflowed. 1 << 0 == Buffer 0, 1 << 1 == Buffer 1, ... Or-combination is possible, indicating that multiple buffers overflowed.
    ("Dummy1",              c_uint32 ),    # Future use. SBZ
  ]

#/*********************************************************************
#*
#*       STRACE_INST_STAT
#*
#*  Class description
#*    This class is used to make the JLINK_STRACE_INST_STAT data easier to handle
#*
#**********************************************************************
#*/
class STRACE_INST_STAT():
  #
  # Constructors
  #
  def __init__(self, ExecCnt = None, FetchCnt = None, SkipCnt = None):
    self.ExecCnt   = ExecCnt
    self.FetchCnt  = FetchCnt
    self.SkipCnt   = SkipCnt

#/*********************************************************************
#*
#*       C_STRACE_INST_STAT
#*
#*  Class description
#*    This class is the python equivalent of the C struct "JLINK_STRACE_INST_STAT"
#*    from JLINKARM_Const.h using C types of the ctypes module.
#*    Instances of this class are only used to be passed directly to the DLL.
#*    After that, conversion to the class STRACE_INST_STAT should be done, so the data can be handled in a pythonic way.
#*
#**********************************************************************
#*/
class C_STRACE_INST_STAT(Structure):
  _fields_ = [
    ( "ExecCnt", c_int64 )
  ]

#/************************** end of file *****************************/
