/*********************************************************************
*              SEGGER MICROCONTROLLER SYSTEME GmbH                   *
*        Solutions for real time microcontroller applications        *
**********************************************************************
*                                                                    *
*          (c) 2006 SEGGER Microcontroller Systeme GmbH              *
*                                                                    *
*       Internet: www.segger.com Support: support@segger.com         *
*                                                                    *
**********************************************************************
----------------------------------------------------------------------
File    : Main.c
Purpose : J-Link sample program for DCC communication
--------- END-OF-HEADER --------------------------------------------
*/

#include <intrinsics.h>

#define CMD_READ  1      // PC writes data to the target, target tries to read data
#define CMD_WRITE 2      // Target writes data via DCC, PC reads
#define U8  unsigned char
#define U16 unsigned short
#define U32 unsigned int

/*********************************************************************
*
*       _ReadDCCStat
*/
static __interwork __arm int _ReadDCCStat(void) {
  return __MRC( 14, 0, 0, 0, 0 );       // __asm("mrc P14,0,R0,C0,C0,0");
}

/*********************************************************************
*
*       _ReadDCC
*/
static __interwork __arm U32 _ReadDCC(void) {
  return __MRC( 14, 0, 1, 0, 0 );       // __asm("mrc P14,0,R0,C1,C0,0");
}

/*********************************************************************
*
*       _WriteDCC
*/
static __interwork __arm void _WriteDCC(U32 Data) {
  __MCR( 14, 0, Data, 1, 0, 0 );        // __asm("mcr P14,0,R0,C1,C0,0");
}

/*********************************************************************
*
*       _WaitReadDCC
*/
static U32 _WaitReadDCC(void) {
  U32 Data;

  while ((_ReadDCCStat() & 1) == 0);
  Data = _ReadDCC();
  return Data;
}

/*********************************************************************
*
*       _WaitWriteDCC
*/
static void _WaitWriteDCC(U32 Data) {
  while ((_ReadDCCStat() & 2) != 0);
  _WriteDCC(Data);
}

/*********************************************************************
*
*       main
*
*********************************************************************/
void main(void) {
  U32 u;
  U32 Sum;
  U32 Cmd;
  U32 Data;
  U32 NumItems;

  while (1) {
    Cmd = _WaitReadDCC();
    if (Cmd == CMD_READ) {
      NumItems = _WaitReadDCC();
      Sum = 0;
      for (u = 0; u < NumItems; u++) {
        Data = _WaitReadDCC();
        Sum += Data;
      }
        _WaitWriteDCC(Sum);
    } else if (Cmd == CMD_WRITE) {
      NumItems = _WaitReadDCC();
      for (u = 0; u < NumItems; u++) {
        _WaitWriteDCC(u);
      }
    }
  }
}//* End
